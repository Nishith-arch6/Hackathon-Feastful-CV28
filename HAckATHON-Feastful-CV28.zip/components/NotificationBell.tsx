import React from 'react';
import BellIcon from './icons/BellIcon';

interface NotificationBellProps {
  count: number;
  onClick: () => void;
}

const NotificationBell: React.FC<NotificationBellProps> = ({ count, onClick }) => {
  return (
    <button
      onClick={onClick}
      className="relative p-2 rounded-full text-gray-600 hover:bg-orange-200 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
      aria-label={`View notifications. ${count} new notifications.`}
    >
      <BellIcon className="w-8 h-8" />
      {count > 0 && (
        <span className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
          {count}
        </span>
      )}
    </button>
  );
};

export default NotificationBell;
