
import React from 'react';
import { OrderNotification } from '../types';
import RupeeIcon from './icons/RupeeIcon';

interface MyOrdersProps {
    orders: OrderNotification[];
    onTrackOrder: (order: OrderNotification) => void;
    onBack: () => void;
}

const MyOrders: React.FC<MyOrdersProps> = ({ orders, onTrackOrder, onBack }) => {
    
    const getStatusChip = (status: OrderNotification['status']) => {
        const styles = {
            pending: 'bg-yellow-100 text-yellow-800',
            accepted: 'bg-green-100 text-green-800',
            out_for_delivery: 'bg-blue-100 text-blue-800',
            delivered: 'bg-gray-200 text-gray-800',
            rejected: 'bg-red-100 text-red-800',
        };
        const text = {
            pending: 'Pending',
            accepted: 'Accepted',
            out_for_delivery: 'Out for Delivery',
            delivered: 'Delivered',
            rejected: 'Rejected',
        }
        return <span className={`px-3 py-1 text-sm font-semibold rounded-full ${styles[status]}`}>{text[status]}</span>;
    }
    
    const activeOrders = orders
        .filter(order => order.status === 'pending' || order.status === 'accepted' || order.status === 'out_for_delivery')
        .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());

    return (
        <div className="container mx-auto max-w-4xl w-full">
            <div className="text-center mb-10">
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">My Active Orders</h2>
                <p className="mt-4 text-xl text-gray-600">Track your ongoing orders here.</p>
            </div>
            
            <div className="bg-orange-50 p-8 rounded-2xl shadow-xl border-2 border-gray-800">
                {activeOrders.length > 0 ? (
                    <div className="space-y-6">
                        {activeOrders.map(order => (
                            <div key={order.id} className="bg-white p-6 rounded-lg shadow-md flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                <div className="flex-grow">
                                    <div className="flex items-center gap-4 mb-2">
                                        <h3 className="text-xl font-bold text-gray-800">Order #{order.id.slice(-6)}</h3>
                                        {getStatusChip(order.status)}
                                    </div>
                                    <p className="text-gray-500 text-sm mb-2">{new Date(order.orderDate).toLocaleString()}</p>
                                    <p className="text-lg font-semibold text-green-600 flex items-center"><RupeeIcon className="mr-1"/>{order.total}</p>
                                </div>
                                <div className="flex-shrink-0">
                                    {(order.status === 'accepted' || order.status === 'out_for_delivery') && (
                                        <button
                                            onClick={() => onTrackOrder(order)}
                                            className="px-6 py-2 text-lg font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors"
                                        >
                                            Track Order
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <p className="text-2xl text-gray-500 mb-6">You haven't placed any orders yet.</p>
                        <button onClick={onBack} className="px-8 py-3 text-lg font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700">
                            Start Shopping
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MyOrders;
