
import React, { useState, useEffect } from 'react';
import UserIcon from './icons/UserIcon';
import FeastfulLogo from './icons/FeastfulLogo';
import MenuIcon from './icons/MenuIcon';
import CartIcon from './icons/CartIcon';

interface HeaderProps {
  isLoggedIn: boolean;
  username: string | null;
  onLoginClick: () => void;
  onLogoutRequest: () => void;
  onHomeClick: () => void;
  onSettingsClick: () => void;
  onCartClick: () => void;
  cartItemCount: number;
  onMyOrdersClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ isLoggedIn, username, onLoginClick, onLogoutRequest, onHomeClick, onSettingsClick, onCartClick, cartItemCount, onMyOrdersClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const headerClasses = `sticky top-0 z-50 transition-all duration-300 ease-in-out ${
    isScrolled ? 'bg-white/90 backdrop-blur-lg shadow-md' : 'bg-transparent'
  }`;

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-6 py-4 flex justify-between items-center gap-6">
        {/* Left Section: Logo and Title */}
        <button 
          onClick={onHomeClick} 
          className="flex items-center gap-4 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 rounded-lg p-1 flex-shrink-0" 
          aria-label="Go to homepage"
        >
          <FeastfulLogo className="w-12 h-12 text-orange-600 transition-transform duration-300 hover:rotate-12" />
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-800 tracking-tight transition-colors">
            Feastful
          </h1>
        </button>

        {/* Right Section: Login/Logout & Settings */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          <button
            onClick={onCartClick}
            className="relative p-2 rounded-full text-gray-600 hover:bg-orange-200/70 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
            aria-label="View shopping cart"
          >
            <CartIcon className="w-7 h-7" />
            {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white animate-popIn">
                    {cartItemCount}
                </span>
            )}
          </button>
        
          {isLoggedIn && username ? (
            <>
              <div className="hidden md:flex items-center space-x-3">
                <span className="text-lg font-medium text-gray-700">Hello, {username}</span>
                <UserIcon className="w-7 h-7 text-gray-600" />
                 <button 
                    onClick={onMyOrdersClick}
                    className="text-lg font-medium text-orange-600 hover:underline"
                >
                    My Orders
                </button>
              </div>
              <button
                onClick={onLogoutRequest}
                className="px-6 py-3 text-lg font-semibold text-white bg-orange-500 rounded-lg hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 transition-all duration-200 shadow-sm hover:shadow-md transform hover:-translate-y-0.5 active:scale-95"
              >
                Logout
              </button>
            </>
          ) : (
            <button
              onClick={onLoginClick}
              className="px-6 py-3 text-lg font-semibold text-white bg-orange-500 rounded-lg hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 transition-all duration-200 shadow-sm hover:shadow-md transform hover:-translate-y-0.5 active:scale-95"
            >
              Login
            </button>
          )}

          {/* Settings Button */}
          <button
            onClick={onSettingsClick}
            className="p-2 rounded-full text-gray-600 hover:bg-orange-200/70 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
            aria-label="Open settings"
          >
            <MenuIcon className="w-7 h-7" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;