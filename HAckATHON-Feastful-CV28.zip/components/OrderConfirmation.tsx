

import React, { useEffect } from 'react';

interface OrderConfirmationProps {
    address: string;
    orderNumber: string | null;
    onBackToHome: () => void;
    onViewOrders: () => void;
}

const OrderConfirmation: React.FC<OrderConfirmationProps> = ({ address, orderNumber, onBackToHome, onViewOrders }) => {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <div className="container mx-auto max-w-2xl w-full flex flex-col items-center justify-center text-center">
            <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-800">
                <div className="w-24 h-24 mx-auto mb-6">
                    <svg className="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                        <circle className="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
                        <path className="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                    </svg>
                </div>
                <h2 className="text-4xl font-extrabold text-green-600 tracking-tight mb-4">
                    Order Placed!
                </h2>

                {orderNumber && (
                    <div className="mb-8 text-center">
                        <p className="text-lg text-gray-600">Your Order ID:</p>
                        <p className="text-2xl font-bold text-gray-800 bg-orange-200 inline-block px-4 py-1 rounded-lg">{orderNumber}</p>
                    </div>
                )}
                
                <p className="text-xl text-gray-700 mb-2">
                    Your delicious meal is on its way.
                </p>
                <div className="mt-8 p-6 bg-orange-100 rounded-lg text-left">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">Delivering To:</h3>
                    <p className="text-lg text-gray-600 whitespace-pre-wrap">{address || 'Your provided address'}</p>
                </div>
                <div className="mt-10 flex flex-col sm:flex-row gap-4">
                    <button
                        onClick={onBackToHome}
                        className="w-full bg-gray-600 text-white text-xl font-bold py-4 rounded-lg hover:bg-gray-700 transition-colors shadow-lg"
                    >
                        Back to Home
                    </button>
                    <button
                        onClick={onViewOrders}
                        className="w-full bg-orange-600 text-white text-xl font-bold py-4 rounded-lg hover:bg-orange-700 transition-colors shadow-lg"
                    >
                        View My Orders
                    </button>
                </div>
            </div>
            <style>{`
                .checkmark__circle {
                    stroke-dasharray: 166;
                    stroke-dashoffset: 166;
                    stroke-width: 2;
                    stroke-miterlimit: 10;
                    stroke: #4ade80;
                    fill: none;
                    animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
                }

                .checkmark {
                    width: 100%;
                    height: 100%;
                    border-radius: 50%;
                    display: block;
                    stroke-width: 2;
                    stroke: #fff;
                    stroke-miterlimit: 10;
                    box-shadow: inset 0px 0px 0px #4ade80;
                    animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
                }

                .checkmark__check {
                    transform-origin: 50% 50%;
                    stroke-dasharray: 48;
                    stroke-dashoffset: 48;
                    animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
                }

                @keyframes stroke {
                    100% {
                        stroke-dashoffset: 0;
                    }
                }

                @keyframes scale {
                    0%, 100% {
                        transform: none;
                    }
                    50% {
                        transform: scale3d(1.1, 1.1, 1);
                    }
                }

                @keyframes fill {
                    100% {
                        box-shadow: inset 0px 0px 0px 50px #4ade80;
                    }
                }
            `}</style>
        </div>
    );
};

export default OrderConfirmation;
