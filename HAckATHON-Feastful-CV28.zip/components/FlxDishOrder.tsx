
import React from 'react';
import { FlxDish } from '../types';
import CartIcon from './icons/CartIcon';

interface FlxDishOrderProps {
  dish: FlxDish;
  onBack: () => void;
  onAddToCart: (dish: FlxDish) => void;
}

const FlxDishOrder: React.FC<FlxDishOrderProps> = ({ dish, onBack, onAddToCart }) => {
  
  const handleAddToCartClick = () => {
      onAddToCart(dish);
  }

  return (
    <div className="container mx-auto max-w-4xl w-full">
      <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-800">
        <div className="mb-8">
          <button
            onClick={onBack}
            className="px-8 py-3 text-lg font-semibold text-black bg-orange-500 rounded-lg hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 transition-colors"
          >
            &larr; Back to Marketplace
          </button>
        </div>

        <div className="flex flex-col text-center items-center">
          {dish.image && (
            <img src={dish.image} alt={dish.name} className="w-full max-w-lg h-auto object-cover rounded-lg mb-8 shadow-lg" />
          )}
          <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight">{dish.name}</h2>
          <p className="text-2xl text-gray-500 mt-2">by {dish.sellerName}</p>
          <p className="text-xl text-gray-700 mt-6 max-w-2xl">{dish.description}</p>

          <button 
            onClick={handleAddToCartClick} 
            className="w-full max-w-sm mt-10 bg-orange-600 text-white text-2xl font-bold py-5 rounded-lg hover:bg-orange-700 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center justify-center gap-4"
          >
              <CartIcon className="w-8 h-8"/>
              Add to Cart
          </button>

        </div>
      </div>
    </div>
  );
};

export default FlxDishOrder;