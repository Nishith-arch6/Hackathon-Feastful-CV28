
import React, { useState } from 'react';
import { OrderNotification } from '../types';
import RupeeIcon from './icons/RupeeIcon';

interface OrderNotificationItemProps {
    order: OrderNotification;
    onUpdate: (order: OrderNotification) => void;
}

const CheckmarkAnimation: React.FC = () => (
    <div className="w-16 h-16 mx-auto">
        <svg className="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
            <circle className="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
            <path className="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
        </svg>
        <style>{`
            .checkmark__circle { stroke-dasharray: 166; stroke-dashoffset: 166; stroke-width: 2; stroke-miterlimit: 10; stroke: #4ade80; fill: none; animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards; }
            .checkmark { width: 100%; height: 100%; border-radius: 50%; display: block; stroke-width: 2; stroke: #fff; stroke-miterlimit: 10; animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both; }
            .checkmark__check { transform-origin: 50% 50%; stroke-dasharray: 48; stroke-dashoffset: 48; animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards; }
            @keyframes stroke { 100% { stroke-dashoffset: 0; } }
            @keyframes scale { 0%, 100% { transform: none; } 50% { transform: scale3d(1.1, 1.1, 1); } }
            @keyframes fill { 100% { box-shadow: inset 0px 0px 0px 30px #4ade80; } }
        `}</style>
    </div>
);

const OrderNotificationItem: React.FC<OrderNotificationItemProps> = ({ order, onUpdate }) => {
    const [showAcceptedAnimation, setShowAcceptedAnimation] = useState(false);

    const handleAccept = () => {
        setShowAcceptedAnimation(true);
        setTimeout(() => {
            onUpdate({ ...order, status: 'accepted' });
            setShowAcceptedAnimation(false);
        }, 2000); // Duration of the animation
    };

    const handleReject = () => {
        onUpdate({ ...order, status: 'rejected' });
    };
    
    const handleDispatch = () => {
        onUpdate({ ...order, status: 'out_for_delivery' });
    }

    const handleDeliver = () => {
        onUpdate({ ...order, status: 'delivered' });
    }

    const getStatusStyles = () => {
        switch(order.status) {
            case 'accepted': return 'border-l-4 border-green-500';
            case 'rejected': return 'border-l-4 border-red-500 bg-gray-100 opacity-70';
            case 'out_for_delivery': return 'border-l-4 border-blue-500';
            case 'delivered': return 'border-l-4 border-gray-400 bg-gray-50';
            default: return 'border-l-4 border-yellow-500';
        }
    }

    if (showAcceptedAnimation) {
        return (
            <div className={`p-4 bg-white rounded-lg shadow-md ${getStatusStyles()}`}>
                <CheckmarkAnimation />
                <p className="text-center font-bold text-green-600 mt-2">Order Accepted!</p>
            </div>
        )
    }

    return (
        <div className={`p-4 bg-white rounded-lg shadow-md ${getStatusStyles()} transition-all`}>
            <div className="flex justify-between items-start">
                <h4 className="font-bold text-lg text-gray-800">Order #{order.id.slice(-4)}</h4>
                <span className="text-sm font-semibold text-gray-500">{order.paymentMethod}</span>
            </div>
            <div className="mt-2 text-gray-700">
                <p><strong className="font-semibold">Customer:</strong> {order.customerName}</p>
                <p><strong className="font-semibold">Address:</strong> {order.address}</p>
                <div className="mt-2 pt-2 border-t">
                    <ul className="list-disc list-inside">
                        {order.items.map(item => (
                            <li key={item.name}>{item.quantity}x {item.name}</li>
                        ))}
                    </ul>
                </div>
                <p className="text-right font-bold text-xl mt-2 flex items-center justify-end"><RupeeIcon className="mr-1"/>{order.total}</p>
            </div>
            
            {order.status === 'pending' && (
                <div className="flex justify-end gap-2 mt-4">
                    <button onClick={handleReject} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg hover:bg-red-600">Reject</button>
                    <button onClick={handleAccept} className="px-4 py-2 text-sm font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700">Accept</button>
                </div>
            )}
            {order.status === 'accepted' && (
                <div className="mt-4">
                    <button onClick={handleDispatch} className="w-full px-4 py-2 text-md font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Dispatch Order</button>
                </div>
            )}
             {order.status === 'out_for_delivery' && (
                <div className="mt-4">
                    <button onClick={handleDeliver} className="w-full px-4 py-2 text-md font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700">Mark Delivered</button>
                </div>
            )}
            {order.status === 'delivered' && (
                <p className="mt-4 text-center font-bold text-gray-600 bg-gray-200 p-2 rounded-lg">Order Completed</p>
            )}
            {order.status === 'rejected' && (
                 <p className="mt-4 text-center font-bold text-red-600 bg-red-100 p-2 rounded-lg">Order Rejected</p>
            )}
        </div>
    );
};

export default OrderNotificationItem;
