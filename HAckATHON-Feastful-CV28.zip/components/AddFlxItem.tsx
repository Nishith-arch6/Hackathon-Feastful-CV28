
import React, { useState } from 'react';
import { FlxDish } from '../types';

interface AddFlxItemProps {
    onAddItem: (item: FlxDish) => void;
    onBack: () => void;
}

const AddFlxItem: React.FC<AddFlxItemProps> = ({ onAddItem, onBack }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [sellerName, setSellerName] = useState('');
    const [availableUntil, setAvailableUntil] = useState('');
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
                setError('Image file is too large. Please select an image smaller than 2MB.');
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
                setError(null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !description || !price || !sellerName || !availableUntil || !imagePreview) {
            setError('All fields, including an image, are required.');
            return;
        }

        const newItem: FlxDish = {
            name,
            description,
            price: parseInt(price, 10),
            sellerName,
            availableUntil,
            image: imagePreview,
        };

        onAddItem(newItem);
    };

    return (
        <div className="container mx-auto max-w-3xl w-full">
            <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-800">
                <div className="flex justify-between items-center mb-8">
                    <h2 className="text-4xl font-extrabold text-gray-800 tracking-tight">Add Your Dish</h2>
                    <button
                        onClick={onBack}
                        className="px-6 py-2 text-lg font-semibold text-black bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                    >
                        &larr; Cancel
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="dish-name" className="block text-xl font-semibold text-gray-700 mb-2">Dish Name</label>
                        <input id="dish-name" type="text" value={name} onChange={e => setName(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white" required />
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-xl font-semibold text-gray-700 mb-2">Description</label>
                        <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white" rows={4} required />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="price" className="block text-xl font-semibold text-gray-700 mb-2">Price (INR)</label>
                            <input id="price" type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white" required min="0" />
                        </div>
                        <div>
                            <label htmlFor="seller-name" className="block text-xl font-semibold text-gray-700 mb-2">Your Name (Seller)</label>
                            <input id="seller-name" type="text" value={sellerName} onChange={e => setSellerName(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white" required />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="availability" className="block text-xl font-semibold text-gray-700 mb-2">Available Until</label>
                        <input id="availability" type="text" placeholder="e.g., 'Tonight 9 PM'" value={availableUntil} onChange={e => setAvailableUntil(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white" required />
                    </div>
                    <div>
                        <label htmlFor="image-upload" className="block text-xl font-semibold text-gray-700 mb-2">Dish Image</label>
                        <input id="image-upload" type="file" accept="image/png, image/jpeg, image/webp" onChange={handleImageChange} className="w-full text-lg text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-lg file:font-semibold file:bg-orange-100 file:text-orange-700 hover:file:bg-orange-200" required />
                        {imagePreview && (
                            <div className="mt-4 border-2 border-dashed border-gray-300 rounded-lg p-2">
                                <img src={imagePreview} alt="Dish preview" className="max-h-64 w-auto mx-auto rounded-md" />
                            </div>
                        )}
                    </div>

                    {error && <p className="text-red-500 text-center text-lg">{error}</p>}

                    <button type="submit" className="w-full mt-4 bg-orange-600 text-white text-2xl font-bold py-5 rounded-lg hover:bg-orange-700 transition-colors shadow-lg disabled:bg-gray-400">
                        Add My Dish to Marketplace
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AddFlxItem;
