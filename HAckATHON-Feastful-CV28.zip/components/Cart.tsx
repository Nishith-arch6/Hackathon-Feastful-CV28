
import React, { useState } from 'react';
import { CartItem } from '../types';
import RupeeIcon from './icons/RupeeIcon';
import CashIcon from './icons/CashIcon';
import CreditCardIcon from './icons/CreditCardIcon';
import UpiIcon from './icons/UpiIcon';
import CartIcon from './icons/CartIcon';

interface CartProps {
    cartItems: CartItem[];
    onUpdateCart: (dishName: string, quantity: number) => void;
    onPlaceOrder: (address: string, paymentMethod: string) => void;
    onBack: () => void;
}

const Cart: React.FC<CartProps> = ({ cartItems, onUpdateCart, onPlaceOrder, onBack }) => {
    const [address, setAddress] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('cod');
    
    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    const handleOrderClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        if (address.trim() && cartItems.length > 0) {
            let paymentMethodName = 'Cash on Delivery';
            if (paymentMethod === 'card') paymentMethodName = 'Card';
            if (paymentMethod === 'upi') paymentMethodName = 'UPI';
            const button = e.currentTarget;
            button.style.animation = 'bounceClick 0.4s ease-out';
            setTimeout(() => {
                button.style.animation = '';
                onPlaceOrder(address, paymentMethodName);
            }, 400);
        }
    }

    const handleQuantityUpdate = (e: React.MouseEvent<HTMLButtonElement>, dishName: string, newQuantity: number) => {
        const button = e.currentTarget;
        button.style.animation = 'bounceClick 0.3s ease-out';
        setTimeout(() => {
            button.style.animation = '';
        }, 300);
        onUpdateCart(dishName, newQuantity);
    }

    if (cartItems.length === 0) {
        return (
            <div className="text-center" style={{ animation: 'fadeAndSlideUp 0.5s ease-out' }}>
                <CartIcon className="w-24 h-24 mx-auto text-gray-300 mb-6" />
                <h2 className="text-4xl font-bold text-gray-800 mb-4">Your Cart is Empty</h2>
                <p className="text-xl text-gray-600 mb-8">Looks like you haven't added any dishes yet!</p>
                <button onClick={onBack} className="px-8 py-3 text-lg font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-transform transform hover:scale-105">
                    Browse Dishes
                </button>
            </div>
        )
    }

    return (
        <div className="container mx-auto max-w-7xl w-full">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Cart Items */}
                <div className="lg:col-span-2">
                    <h2 className="text-4xl font-extrabold text-gray-800 tracking-tight mb-8">Your Cart</h2>
                    <div className="space-y-6">
                        {cartItems.map((item, index) => (
                            <div key={item.name} className="flex items-center bg-white p-4 rounded-lg shadow-md gap-4" style={{ animation: `fadeAndSlideUp 0.5s ease-out ${index * 0.1}s backwards` }}>
                                {item.image && <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md"/>}
                                <div className="flex-grow">
                                    <h3 className="text-xl font-bold text-gray-800">{item.name}</h3>
                                    <p className="text-sm text-gray-500">by {item.sellerName}</p>
                                    <p className="text-lg font-semibold text-green-600 flex items-center mt-1"><RupeeIcon className="mr-1"/>{item.price}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={(e) => handleQuantityUpdate(e, item.name, item.quantity - 1)} className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 text-black transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" /></svg>
                                    </button>
                                    <span className="text-xl font-bold text-black w-8 text-center">{item.quantity}</span>
                                    <button onClick={(e) => handleQuantityUpdate(e, item.name, item.quantity + 1)} className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 text-black transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" /></svg>
                                    </button>
                                </div>
                                <div className="text-lg font-bold text-gray-800 w-24 text-right">
                                    <RupeeIcon /> {item.price * item.quantity}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Order Summary & Checkout */}
                <div className="bg-orange-50 p-8 rounded-2xl shadow-xl border-2 border-gray-200 self-start" style={{ animation: 'fadeAndSlideUp 0.6s ease-out 0.2s backwards' }}>
                    <h3 className="text-3xl font-bold text-gray-800 mb-6">Order Summary</h3>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="address" className="block text-xl font-semibold text-gray-700 mb-2">Delivery Address</label>
                            <textarea id="address" value={address} onChange={e => setAddress(e.target.value)} rows={3} className="w-full p-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white text-black" placeholder="Enter your full address" required />
                        </div>
                        <div>
                            <h4 className="block text-xl font-semibold text-gray-700 mb-3">Payment Method</h4>
                            <div className="space-y-3">
                                <button onClick={() => setPaymentMethod('cod')} className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${paymentMethod === 'cod' ? 'bg-orange-200/50 border-orange-500' : 'bg-white border-gray-300 hover:border-orange-400'}`}>
                                    <CashIcon className="w-7 h-7 text-green-600" /> <span className="font-semibold">Cash on Delivery</span>
                                </button>
                                <button onClick={() => setPaymentMethod('card')} className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${paymentMethod === 'card' ? 'bg-orange-200/50 border-orange-500' : 'bg-white border-gray-300 hover:border-orange-400'}`}>
                                    <CreditCardIcon className="w-7 h-7 text-blue-600" /> <span className="font-semibold">Credit/Debit Card</span>
                                </button>
                                <button onClick={() => setPaymentMethod('upi')} className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${paymentMethod === 'upi' ? 'bg-orange-200/50 border-orange-500' : 'bg-white border-gray-300 hover:border-orange-400'}`}>
                                    <UpiIcon className="w-7 h-7 text-purple-600" /> <span className="font-semibold">UPI</span>
                                </button>
                            </div>
                        </div>
                        <div className="text-2xl font-bold text-gray-800 flex justify-between items-center pt-4 border-t-2 mt-4">
                            <span>Total</span>
                            <span className="flex items-center"><RupeeIcon className="mr-1"/>{total}</span>
                        </div>
                        <button onClick={handleOrderClick} disabled={!address.trim()} className="w-full mt-6 bg-orange-600 text-white text-2xl font-bold py-4 rounded-lg hover:bg-orange-700 transition-all shadow-lg transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100">
                            Place Order
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Cart;