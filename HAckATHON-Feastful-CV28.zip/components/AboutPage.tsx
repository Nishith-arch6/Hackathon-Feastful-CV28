
import React from 'react';

const AboutPage: React.FC = () => {
    return (
        <div className="container mx-auto max-w-5xl w-full animate-fade-in">
            <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-800">
                <div className="text-center mb-16">
                    <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">About Feastful</h2>
                    <p className="mt-6 text-2xl text-gray-600">Your Community Food Connection.</p>
                </div>

                <div className="space-y-16">
                    {/* How to Become a Seller */}
                    <div>
                        <h3 className="text-4xl font-bold text-gray-800 mb-8 text-center">How to Become a Seller</h3>
                        <div className="flex flex-col md:flex-row items-center justify-center gap-8 text-center text-lg text-gray-700">
                            <div className="flex flex-col items-center">
                                <div className="w-24 h-24 bg-orange-500 text-white rounded-full flex items-center justify-center text-4xl font-bold mb-4">1</div>
                                <p className="font-semibold">Open Settings</p>
                                <p className="max-w-xs">Click the menu icon in the top-right corner to open the settings panel.</p>
                            </div>
                            <div className="text-4xl text-orange-400 md:rotate-0 rotate-90">&rarr;</div>
                             <div className="flex flex-col items-center">
                                <div className="w-24 h-24 bg-orange-500 text-white rounded-full flex items-center justify-center text-4xl font-bold mb-4">2</div>
                                <p className="font-semibold">Switch to Seller Mode</p>
                                <p className="max-w-xs">Use the 'Mode' switch to change from 'Buyer' to 'Seller'.</p>
                            </div>
                             <div className="text-4xl text-orange-400 md:rotate-0 rotate-90">&rarr;</div>
                            <div className="flex flex-col items-center">
                                <div className="w-24 h-24 bg-orange-500 text-white rounded-full flex items-center justify-center text-4xl font-bold mb-4">3</div>
                                <p className="font-semibold">Fill Your Details</p>
                                <p className="max-w-xs">Enter your contact and address details and click 'Save'. You're all set!</p>
                            </div>
                        </div>
                    </div>

                    {/* What is FLX */}
                    <div className="pt-16 border-t-2 border-dashed border-orange-300">
                        <h3 className="text-4xl font-bold text-gray-800 mb-8 text-center">What is FLX? (Food Lover's Exchange)</h3>
                        <div className="text-xl text-gray-700 space-y-6 max-w-3xl mx-auto text-left">
                            <p>
                                <strong className="text-orange-600">FLX is our answer to food waste and a celebration of home cooking.</strong> Think of it as an "OLX for food"—a community marketplace where home chefs can sell their extra, freshly prepared meals to others in their neighborhood.
                            </p>
                            <ul className="list-disc list-inside space-y-4 pl-4">
                                <li>
                                    <strong className="font-semibold">Ultra-Fresh, Ultra-Local:</strong> Dishes on FLX are typically available for only a few hours. This isn't mass-produced food; it's the extra dal or biryani that a home cook has lovingly prepared and wants to share.
                                </li>
                                <li>
                                    <strong className="font-semibold">Reduce Waste, Share Joy:</strong> Instead of letting good food go to waste, sellers can earn from their culinary skills, and buyers get access to authentic, home-cooked meals they can't find anywhere else.
                                </li>
                                <li>
                                    <strong className="font-semibold">A Taste of Home:</strong> FLX connects you to the heart of your community's kitchens. It's about sustainability, connection, and the simple joy of sharing a good meal.
                                </li>
                            </ul>
                            <p className="font-bold text-center mt-8">
                                With FLX, every meal has a story. Be a part of it!
                            </p>
                        </div>
                    </div>

                     {/* Navigating Feastful */}
                    <div className="pt-16 border-t-2 border-dashed border-orange-300">
                        <h3 className="text-4xl font-bold text-gray-800 mb-8 text-center">Navigating Feastful</h3>
                        <div className="space-y-6 max-w-3xl mx-auto text-left">
                            <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">Home</h4>
                                <p className="mt-2 text-lg text-gray-700">This is your main landing page. For buyers, it showcases 'Today's Fresh Picks'. For sellers, it transforms into a powerful dashboard showing your live orders and featured items.</p>
                            </div>
                            <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">About</h4>
                                <p className="mt-2 text-lg text-gray-700">You are here! This page provides essential information about how Feastful works, from becoming a seller to understanding our navigation buttons.</p>
                            </div>
                            <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">Explore the Taste</h4>
                                <p className="mt-2 text-lg text-gray-700">Embark on a culinary tour of India. Select any state to discover its unique food culture, learn fun facts, and view its most famous dishes. Click a dish to get its full recipe.</p>
                            </div>
                             <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">FLX</h4>
                                <p className="mt-2 text-lg text-gray-700">The heart of our community: the Food Lover's Exchange. This is the marketplace where you can buy fresh, home-cooked meals from local chefs or sell your own delicious extras.</p>
                            </div>
                             <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">Chef's Challenge</h4>
                                <p className="mt-2 text-lg text-gray-700">Don't know what to cook? Challenge our AI Chef! Type in the ingredients you have, and it will generate a creative recipe for you on the spot.</p>
                            </div>
                            <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
                                <h4 className="text-2xl font-bold text-orange-600">Awareness of Food</h4>
                                <p className="mt-2 text-lg text-gray-700">A space for mindfulness. Learn impactful facts about the global reality of food waste and the importance of food to our health and culture.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             <style>{`
                .animate-fade-in {
                    animation: fadeIn 0.5s ease-in-out;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
};

export default AboutPage;
