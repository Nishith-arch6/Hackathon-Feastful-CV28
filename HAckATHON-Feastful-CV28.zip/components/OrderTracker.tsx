
import React from 'react';
import { OrderNotification } from '../types';
import PackageIcon from './icons/PackageIcon';
import ChefHatIcon from './icons/ChefHatIcon';
import TruckIcon from './icons/TruckIcon';
import HomeIcon from './icons/HomeIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import StorefrontIcon from './icons/StorefrontIcon';

interface OrderTrackerProps {
    order: OrderNotification;
    onBack: () => void;
}

const OrderTracker: React.FC<OrderTrackerProps> = ({ order, onBack }) => {
    const statuses: OrderNotification['status'][] = ['pending', 'accepted', 'out_for_delivery', 'delivered'];
    const currentStatusIndex = statuses.indexOf(order.status);

    const getStageDetails = (stage: OrderNotification['status']) => {
        switch (stage) {
            case 'pending': return { title: 'Order Placed', icon: <PackageIcon className="w-8 h-8" /> };
            case 'accepted': return { title: 'Order Accepted', icon: <ChefHatIcon className="w-8 h-8" /> };
            case 'out_for_delivery': return { title: 'Out for Delivery', icon: <TruckIcon className="w-8 h-8" /> };
            case 'delivered': return { title: 'Delivered', icon: <HomeIcon className="w-8 h-8" /> };
            default: return { title: '', icon: null };
        }
    };
    
    if (order.status === 'rejected') {
        return (
            <div className="container mx-auto max-w-3xl w-full text-center">
                 <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-800" style={{ animation: 'fadeAndSlideUp 0.5s ease-out' }}>
                    <button onClick={onBack} className="text-lg font-semibold text-orange-600 hover:underline mb-8">&larr; Back to My Orders</button>
                    <h2 className="text-4xl font-extrabold text-red-600 tracking-tight">Order Rejected</h2>
                    <p className="mt-4 text-xl text-gray-600">Unfortunately, this order was rejected by the seller.</p>
                    <p className="mt-2 text-gray-500">Order ID: #{order.id.slice(-6)}</p>
                 </div>
            </div>
        )
    }

    return (
        <div className="container mx-auto max-w-4xl w-full">
            <div className="bg-orange-50 p-10 rounded-2xl shadow-xl border-2 border-gray-200">
                <div className="mb-10">
                    <button onClick={onBack} className="text-lg font-semibold text-orange-600 hover:underline">&larr; Back to My Orders</button>
                    <h2 className="text-4xl font-extrabold text-gray-800 tracking-tight text-center mt-2">Tracking Order #{order.id.slice(-6)}</h2>
                </div>

                <div className="flex items-center justify-between relative max-w-3xl mx-auto mb-10">
                    {/* Progress Bar Line */}
                    <div className="absolute left-0 top-1/2 w-full h-1.5 bg-gray-300 transform -translate-y-1/2 rounded-full">
                       <div className="h-full bg-green-500 transition-all duration-700 ease-out rounded-full" style={{ width: `${(currentStatusIndex / (statuses.length - 1)) * 100}%`}}></div>
                    </div>
                    
                    {/* Status Nodes */}
                    {statuses.map((stage, index) => {
                        const { title, icon } = getStageDetails(stage);
                        const isCompleted = index <= currentStatusIndex;
                        const isCurrent = index === currentStatusIndex;

                        return (
                            <div key={stage} className="relative z-10 flex flex-col items-center text-center">
                                <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
                                    isCompleted ? 'bg-green-500 text-white shadow-lg' : 'bg-gray-300 text-gray-500'
                                } ${isCurrent ? 'ring-4 ring-offset-4 ring-offset-orange-50 ring-green-500 animate-popIn' : ''}`} style={{ animationDelay: isCurrent ? '0.2s' : '0s' }}>
                                    {isCompleted && stage !== 'delivered' && !isCurrent ? <CheckCircleIcon className="w-10 h-10" /> : icon}
                                </div>
                                <p className={`mt-3 text-lg font-bold transition-colors ${isCompleted ? 'text-gray-800' : 'text-gray-500'}`}>
                                    {title}
                                </p>
                            </div>
                        );
                    })}
                </div>

                {/* --- START: New Map Section --- */}
                {(order.status === 'out_for_delivery' || order.status === 'delivered') && (
                    <div className="mt-16" style={{ animation: 'fadeAndSlideUp 0.6s ease-out 0.3s backwards' }}>
                        <h3 className="text-2xl font-bold text-gray-800 text-center mb-6">Live Tracking</h3>
                        <div className="relative w-full h-48 bg-blue-50 rounded-lg p-6 overflow-hidden map-bg border-2 border-blue-100">
                            {/* Path */}
                            <div className="absolute top-1/2 left-16 right-16 h-px transform -translate-y-1/2">
                               <div className="w-full h-1 bg-gray-300 relative overflow-hidden rounded-full">
                                   <div className="absolute top-0 left-0 h-full w-full bg-repeat-x animate-road-line" style={{ background: 'linear-gradient(90deg, white 50%, transparent 50%)', backgroundSize: '20px 4px' }}></div>
                               </div>
                            </div>
                            
                            {/* Seller */}
                            <div className="absolute left-6 top-1/2 -translate-y-1/2 flex flex-col items-center w-20">
                                <div className="p-3 bg-white rounded-full shadow-md"><StorefrontIcon className="w-8 h-8 text-gray-700" /></div>
                                <p className="font-bold text-sm mt-2 text-gray-700">Seller</p>
                            </div>
                            
                            {/* Buyer */}
                            <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-center w-20">
                                <div className="p-3 bg-white rounded-full shadow-md"><HomeIcon className="w-8 h-8 text-gray-700" /></div>
                                <p className="font-bold text-sm mt-2 text-gray-700">You</p>
                            </div>
                            
                            {/* Truck */}
                            <div className={`absolute top-1/2 transition-all duration-1000 ${order.status === 'out_for_delivery' ? 'animate-drive' : 'at-destination'}`}>
                                 <TruckIcon className="w-16 h-16 text-orange-600 transform -translate-y-10 -translate-x-1/2" style={{ filter: 'drop-shadow(2px 2px 4px rgba(0,0,0,0.2))' }} />
                            </div>
                        </div>
                        <style>{`
                            .map-bg {
                                background-image: radial-gradient(#dbeafe 1px, transparent 1px);
                                background-size: 10px 10px;
                            }
                            .at-destination {
                                left: calc(100% - 4rem);
                            }
                            .animate-drive {
                                animation: drive-animation 15s ease-in-out forwards;
                            }
                            .animate-road-line {
                                animation: move-lines 0.5s linear infinite;
                            }
                            @keyframes drive-animation {
                                from {
                                    left: 4rem;
                                }
                                to {
                                    left: calc(100% - 4rem);
                                }
                            }
                            @keyframes move-lines {
                                from { background-position: 0 0; }
                                to { background-position: -20px 0; }
                            }
                        `}</style>
                    </div>
                )}
                {/* --- END: New Map Section --- */}
            </div>
        </div>
    );
};

export default OrderTracker;