
import React, { useState, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedRecipe } from '../types';
import ChefHatIcon from './icons/ChefHatIcon';

interface ChefsChallengeProps {
    apiCache: Record<string, any>;
    updateApiCache: (key: string, value: any) => void;
}

const ChefsChallenge: React.FC<ChefsChallengeProps> = ({ apiCache, updateApiCache }) => {
    const [ingredients, setIngredients] = useState('');
    const [recipe, setRecipe] = useState<GeneratedRecipe | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerateRecipe = useCallback(async () => {
        if (!ingredients.trim()) {
            setError('Please enter some ingredients to get started.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setRecipe(null);

        const cacheKey = `chefs_challenge_${ingredients.trim().toLowerCase()}`;
        if (apiCache[cacheKey]) {
            setRecipe(apiCache[cacheKey]);
            setIsLoading(false);
            return;
        }

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const schema = {
                type: Type.OBJECT,
                properties: {
                  recipeName: { type: Type.STRING, description: "A creative and appealing name for the dish." },
                  description: { type: Type.STRING, description: "A short, tantalizing description of the dish (1-2 sentences)." },
                  ingredients: {
                    type: Type.ARRAY,
                    description: "A list of all ingredients needed for the recipe, including quantities.",
                    items: { type: Type.STRING }
                  },
                  instructions: {
                    type: Type.ARRAY,
                    description: "Step-by-step instructions to prepare the dish.",
                    items: { type: Type.STRING }
                  }
                },
                required: ['recipeName', 'description', 'ingredients', 'instructions']
            };

            const recipeResponse = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: `Based on these ingredients: "${ingredients}", invent a creative recipe. You can assume common pantry staples like salt, pepper, oil, and water are available. It is critical that you always return a valid recipe in the requested JSON format. If the provided ingredients are insufficient for a full, standard recipe, invent a creative and plausible recipe using only the items given, but ALSO use the 'description' field to suggest what other ingredients could be added to make a more common or elaborate dish. For example, if given 'chicken, salt', the recipe could be 'Simple Salt-rubbed Chicken' and the description could say 'For a more complete meal, consider adding garlic, lemon, and herbs for a classic roasted chicken.'. If the ingredients are nonsensical (e.g., 'rocks and pencils'), create a fun, fictional recipe name and use the description field to explain why a real recipe can't be made. You must always respond in the requested JSON format, do not fail.`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: schema,
                },
            });

            const parsedRecipe = JSON.parse(recipeResponse.text.trim());
            const finalRecipe: GeneratedRecipe = { ...parsedRecipe };

            setRecipe(finalRecipe);
            updateApiCache(cacheKey, finalRecipe);

        } catch (e) {
            console.error(e);
            setError("Sorry, we couldn't cook up a recipe with those ingredients. Please try a different combination or be more specific.");
        } finally {
            setIsLoading(false);
        }
    }, [ingredients, apiCache, updateApiCache]);
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleGenerateRecipe();
        }
    }

    return (
        <div className="container mx-auto max-w-5xl w-full">
            <div className="text-center mb-10">
                <ChefHatIcon className="w-20 h-20 mx-auto text-orange-600 mb-4" />
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
                    Chef's Challenge
                </h2>
                <p className="mt-6 text-2xl text-gray-600 max-w-3xl mx-auto">
                    Got leftover ingredients? Don't know what to cook? Challenge our AI chef!
                </p>
            </div>

            <div className="bg-orange-50 p-8 rounded-2xl shadow-xl border-2 border-gray-800">
                <div className="flex flex-col sm:flex-row gap-4">
                    <textarea
                        value={ingredients}
                        onChange={(e) => setIngredients(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="e.g., chicken, tomatoes, onion, ginger, and some basic spices"
                        className="w-full p-4 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white text-gray-800"
                        rows={3}
                        aria-label="Enter your ingredients"
                    />
                    <button 
                        onClick={handleGenerateRecipe}
                        disabled={isLoading}
                        className="w-full sm:w-auto px-10 py-4 text-xl font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors shadow-lg disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? (
                            <svg className="animate-spin h-7 w-7 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : "Generate Recipe" }
                    </button>
                </div>
                 {error && <p className="text-red-500 text-center text-lg mt-4" role="alert">{error}</p>}
            </div>
            
            {isLoading && !recipe && (
                 <div className="text-center mt-12">
                    <p className="text-2xl text-gray-600 font-semibold">Consulting our master chefs...</p>
                 </div>
            )}
            
            {recipe && (
                <div className="mt-12 bg-white p-10 rounded-2xl shadow-xl animate-fade-in">
                     <div className="text-center mb-8">
                        <h3 className="text-4xl font-extrabold text-gray-800 tracking-tight">{recipe.recipeName}</h3>
                        <p className="mt-4 text-xl text-gray-700 max-w-3xl mx-auto">{recipe.description}</p>
                     </div>
                    <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-12 border-t pt-8">
                        <div>
                            <h4 className="text-3xl font-bold text-gray-800 mb-4">Ingredients</h4>
                            <ul className="space-y-2 list-disc list-inside text-xl text-gray-700">
                                {recipe.ingredients.map((item, index) => <li key={index}>{item}</li>)}
                            </ul>
                        </div>
                         <div>
                            <h4 className="text-3xl font-bold text-gray-800 mb-4">Instructions</h4>
                            <ol className="space-y-4 list-decimal list-inside text-xl text-gray-700">
                                {recipe.instructions.map((step, index) => <li key={index} className="pl-2">{step}</li>)}
                            </ol>
                        </div>
                    </div>
                </div>
            )}
            <style>{`
                .animate-fade-in {
                    animation: fadeIn 0.5s ease-in-out;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
};

export default ChefsChallenge;
