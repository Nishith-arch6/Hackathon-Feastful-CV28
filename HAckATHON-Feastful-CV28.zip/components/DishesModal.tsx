import React from 'react';

interface DishesModalProps {
  stateName: string;
  dishes: string[];
  isLoading: boolean;
  error: string | null;
  onClose: () => void;
  onDishClick: (dishName: string) => void;
}

const DishesModal: React.FC<DishesModalProps> = ({ stateName, dishes, isLoading, error, onClose, onDishClick }) => {
  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 transition-opacity"
        onClick={onClose}
      >
        <div
          className="relative bg-orange-50 rounded-2xl shadow-2xl p-10 w-full max-w-3xl text-left transform transition-all scale-100 max-h-[90vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between items-start mb-8">
            <h2 className="text-4xl font-bold text-gray-800">
              Special Dishes from <span className="text-orange-600">{stateName}</span>
            </h2>
            <button onClick={onClose} className="text-5xl font-bold text-gray-400 hover:text-gray-600 leading-none -mt-2">&times;</button>
          </div>

          <div className="overflow-y-auto pr-4 -mr-4">
            {isLoading && (
              <div className="flex flex-col items-center justify-center h-64">
                <svg className="animate-spin h-16 w-16 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="mt-6 text-lg text-gray-600">Fetching delicious dishes...</p>
              </div>
            )}

            {error && <p className="text-red-500 text-center text-lg" role="alert">{error}</p>}

            {!isLoading && !error && dishes.length > 0 && (
              <div className="flex flex-wrap justify-center gap-5 py-4">
                {dishes.map((dishName, index) => (
                  <button
                    key={index}
                    onClick={() => onDishClick(dishName)}
                    className="bg-white text-orange-600 font-semibold text-lg py-4 px-6 rounded-lg shadow-md hover:bg-orange-100 hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-orange-500 border border-gray-800"
                  >
                    {dishName}
                  </button>
                ))}
              </div>
            )}
            
            {!isLoading && !error && dishes.length === 0 && (
              <p className="text-gray-500 text-center h-64 flex items-center justify-center text-lg">No dishes found. Try another state!</p>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default DishesModal;