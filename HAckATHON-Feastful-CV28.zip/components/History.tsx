
import React, { useState } from 'react';
import { OrderNotification } from '../types';
import RupeeIcon from './icons/RupeeIcon';
import StarIcon from './icons/StarIcon';

interface HistoryProps {
    orders: OrderNotification[];
    onSaveReview: (orderId: string, rating: number, description: string) => void;
    onBack: () => void;
}

const ReviewForm: React.FC<{ orderId: string, onSave: (orderId: string, rating: number, description: string) => void }> = ({ orderId, onSave }) => {
    const [rating, setRating] = useState(0);
    const [hoverRating, setHoverRating] = useState(0);
    const [description, setDescription] = useState('');
    const [error, setError] = useState('');

    const handleSave = () => {
        if (rating === 0) {
            setError('Please select a star rating.');
            return;
        }
        if (!description.trim()) {
            setError('Please write a short review.');
            return;
        }
        setError('');
        onSave(orderId, rating, description);
    };

    return (
        <div className="mt-4 pt-4 border-t-2 border-dashed border-orange-200">
            <h4 className="font-semibold text-lg text-gray-700 mb-2">Leave a Review</h4>
            <div className="flex items-center mb-3">
                {[1, 2, 3, 4, 5].map(star => (
                    <button
                        key={star}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        onClick={() => setRating(star)}
                        className="text-3xl focus:outline-none"
                    >
                        <StarIcon
                            className={`w-8 h-8 transition-colors ${
                                star <= (hoverRating || rating) ? 'text-yellow-400' : 'text-gray-300'
                            }`}
                        />
                    </button>
                ))}
            </div>
            <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="How was your meal?"
                className="w-full p-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white text-black"
                rows={3}
            />
            {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            <button
                onClick={handleSave}
                className="mt-2 px-4 py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
            >
                Submit Review
            </button>
        </div>
    );
};

const History: React.FC<HistoryProps> = ({ orders, onSaveReview, onBack }) => {
    
    const historyOrders = orders
        .filter(order => order.status === 'delivered' || order.status === 'rejected')
        .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());

    const getStatusChip = (status: OrderNotification['status']) => {
        const styles = {
            delivered: 'bg-gray-200 text-gray-800',
            rejected: 'bg-red-100 text-red-800',
        };
        const text = {
            delivered: 'Delivered',
            rejected: 'Rejected',
        }
        return <span className={`px-3 py-1 text-sm font-semibold rounded-full ${styles[status] || ''}`}>{text[status] || ''}</span>;
    }

    return (
        <div className="container mx-auto max-w-4xl w-full">
            <div className="text-center mb-10">
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">Order History</h2>
                <p className="mt-4 text-xl text-gray-600">A record of your past orders.</p>
            </div>
            
            <div className="bg-orange-50 p-8 rounded-2xl shadow-xl border-2 border-gray-800">
                {historyOrders.length > 0 ? (
                    <div className="space-y-6">
                        {historyOrders.map(order => (
                            <div key={order.id} className="bg-white p-6 rounded-lg shadow-md">
                                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                                    <div className="flex-grow">
                                        <div className="flex items-center gap-4 mb-2">
                                            <h3 className="text-xl font-bold text-gray-800">Order #{order.id.slice(-6)}</h3>
                                            {getStatusChip(order.status)}
                                        </div>
                                        <p className="text-gray-500 text-sm mb-2">{new Date(order.orderDate).toLocaleString()}</p>
                                        <p className="text-lg font-semibold text-green-600 flex items-center"><RupeeIcon className="mr-1"/>{order.total}</p>
                                    </div>
                                    <div className="text-sm text-gray-600 text-left sm:text-right">
                                        {order.items.map(item => (
                                            <div key={item.name}>{item.quantity}x {item.name}</div>
                                        ))}
                                    </div>
                                </div>
                                {order.status === 'delivered' && (
                                    order.review ? (
                                        <div className="mt-4 pt-4 border-t-2 border-dashed border-orange-200">
                                            <h4 className="font-semibold text-lg text-gray-700">Your Review</h4>
                                            <div className="flex items-center my-1">
                                                {[...Array(5)].map((_, i) => (
                                                    <StarIcon key={i} className={`w-5 h-5 ${i < order.review.rating ? 'text-yellow-400' : 'text-gray-300'}`} />
                                                ))}
                                            </div>
                                            <p className="text-gray-600 italic">"{order.review.description}"</p>
                                        </div>
                                    ) : (
                                        <ReviewForm orderId={order.id} onSave={onSaveReview} />
                                    )
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <p className="text-2xl text-gray-500 mb-6">You have no past orders.</p>
                        <button onClick={onBack} className="px-8 py-3 text-lg font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700">
                            Back to Home
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default History;