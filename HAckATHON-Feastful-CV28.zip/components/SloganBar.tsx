import React from 'react';

const SloganBar: React.FC = () => {
  return (
    <div className="bg-orange-100/80 py-6 px-6">
      <div className="container mx-auto text-center">
          <p className="text-2xl md:text-3xl font-semibold tracking-wide slogan-text">
            From Our Home to Yours: <span className="font-bold">Authentic Flavors, Delivered with Love.</span>
          </p>
      </div>
      <style>{`
        .slogan-text {
            background: linear-gradient(90deg, #ca8a04, #fb923c, #9a3412, #fb923c, #ca8a04);
            background-size: 300% 100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradient-flow 10s linear infinite;
        }
        @keyframes gradient-flow {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
      `}</style>
    </div>
  );
};

export default SloganBar;