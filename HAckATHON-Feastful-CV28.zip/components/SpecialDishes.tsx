
import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import SearchIcon from './icons/SearchIcon';
import SkeletonCard from './SkeletonCard';

const indianStatesAndDishes = [
    { name: 'Andhra Pradesh', dish: 'Gutti Vankaya Kura' }, { name: 'Arunachal Pradesh', dish: 'Thukpa' }, { name: 'Assam', dish: 'Masor Tenga' },
    { name: 'Bihar', dish: 'Litti Chokha' }, { name: 'Chhattisgarh', dish: 'Chila' }, { name: 'Goa', dish: 'Goan Fish Curry' },
    { name: 'Gujarat', dish: 'Dhokla' }, { name: 'Haryana', dish: 'Bajra Khichdi' }, { name: 'Himachal Pradesh', dish: 'Dham' },
    { name: 'Jharkhand', dish: 'Dhuska' }, { name: 'Karnataka', dish: 'Bisi Bele Bath' }, { name: 'Kerala', dish: 'Sadya' },
    { name: 'Madhya Pradesh', dish: 'Poha Jalebi' }, { name: 'Maharashtra', dish: 'Vada Pav' }, { name: 'Manipur', dish: 'Eromba' },
    { name: 'Meghalaya', dish: 'Jadoh' }, { name: 'Mizoram', dish: 'Misa Mach Poora' }, { name: 'Nagaland', dish: 'Smoked Pork with Axone' },
    { name: 'Odisha', dish: 'Dalma' }, { name: 'Punjab', dish: 'Sarson da Saag and Makki di Roti' }, { name: 'Rajasthan', dish: 'Dal Baati Churma' },
    { name: 'Sikkim', dish: 'Momo' }, { name: 'Tamil Nadu', dish: 'Pongal' }, { name: 'Telangana', dish: 'Hyderabadi Biryani' },
    { name: 'Tripura', dish: 'Chauk' }, { name: 'Uttar Pradesh', dish: 'Tunday Kababi' }, { name: 'Uttarakhand', dish: 'Kafuli' },
    { name: 'West Bengal', dish: 'Kosha Mangsho' }, { name: 'Andaman and Nicobar Islands', dish: 'Fish Curry' }, { name: 'Chandigarh', dish: 'Butter Chicken' },
    { name: 'Dadra and Nagar Haveli and Daman and Diu', dish: 'Gamthi Chicken' }, { name: 'Delhi', dish: 'Chole Bhature' }, { name: 'Jammu and Kashmir', dish: 'Rogan Josh' },
    { name: 'Ladakh', dish: 'Skyu' }, { name: 'Lakshadweep', dish: 'Octopus Fry' }, { name: 'Puducherry', dish: 'Kadan Prawn Masala' }
];

interface SpecialDishesProps {
    onDishClick: (dishName: string, stateName: string) => void;
    onStateSelect: (stateName: string) => void;
    selectedState: string | null;
    onBackToStates: () => void;
    apiCache: Record<string, any>;
    updateApiCache: (key: string, value: any) => void;
}

const StateListView: React.FC<{ onStateSelect: (stateName: string) => void }> = ({ onStateSelect }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredStates = indianStatesAndDishes.filter(state =>
        state.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="container mx-auto">
            <div className="text-center mb-10">
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
                    Explore the Tastes of India
                </h2>
                <p className="mt-4 text-xl text-gray-600">Select a state or union territory to discover its culinary specialties.</p>
            </div>
             <div className="relative mb-10 max-w-lg mx-auto">
                <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
                <input
                    type="text"
                    placeholder="Search for a state or territory..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-14 pr-4 py-4 text-lg border-2 border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-500 bg-white text-black shadow-inner"
                />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredStates.map(({ name }, index) => (
                    <button
                        key={name}
                        onClick={() => onStateSelect(name)}
                        className="bg-white p-5 rounded-xl shadow-lg hover:bg-orange-100 hover:shadow-xl transform hover:-translate-y-2 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-orange-500 border border-gray-200 text-center"
                        style={{ animation: `fadeAndSlideUp 0.5s ease-out ${index * 0.05}s backwards` }}
                    >
                      <span className="font-semibold text-lg text-gray-800">{name}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

const DishListView: React.FC<{ 
    stateName: string;
    onDishClick: (dishName: string, stateName: string) => void; 
    onBack: () => void;
    apiCache: Record<string, any>;
    updateApiCache: (key: string, value: any) => void;
}> = ({ stateName, onDishClick, onBack, apiCache, updateApiCache }) => {
    const [dishes, setDishes] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [foodFact, setFoodFact] = useState<string | null>(null);
    const [isLoadingFact, setIsLoadingFact] = useState(true);

    const fetchDishesForState = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        const cacheKey = `dishes_${stateName}`;

        if (apiCache[cacheKey]) {
            setDishes(apiCache[cacheKey]);
            setIsLoading(false);
            return;
        }

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const schema = {
                type: Type.OBJECT,
                properties: {
                  dishes: {
                    type: Type.ARRAY,
                    description: "A list of famous dishes from the state.",
                    items: { type: Type.STRING }
                  }
                },
                required: ["dishes"]
            };

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: `List 5 to 8 of the most famous and special food dishes from the state of ${stateName}, India.`,
                config: {
                  responseMimeType: "application/json",
                  responseSchema: schema,
                },
            });

            const parsedResponse = JSON.parse(response.text.trim());
            if (parsedResponse.dishes && parsedResponse.dishes.length > 0) {
                setDishes(parsedResponse.dishes);
                updateApiCache(cacheKey, parsedResponse.dishes);
            } else {
                setError(`Could not find any special dishes for ${stateName}.`);
            }
        } catch (e) {
            console.error(e);
            setError(`Sorry, an error occurred while fetching dishes for ${stateName}.`);
        } finally {
            setIsLoading(false);
        }
    }, [stateName, apiCache, updateApiCache]);

    const fetchFoodFact = useCallback(async () => {
        setIsLoadingFact(true);
        const cacheKey = `fact_${stateName}`;
        if (apiCache[cacheKey]) {
            setFoodFact(apiCache[cacheKey]);
            setIsLoadingFact(false);
            return;
        }

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const schema = {
                type: Type.OBJECT,
                properties: { fact: { type: Type.STRING, description: "An interesting food fact." } },
                required: ["fact"]
            };

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: `Provide one interesting and concise fun fact about the food culture or a famous dish from ${stateName}, India.`,
                config: {
                  responseMimeType: "application/json",
                  responseSchema: schema,
                },
            });

            const parsedResponse = JSON.parse(response.text.trim());
            if (parsedResponse.fact) {
                setFoodFact(parsedResponse.fact);
                updateApiCache(cacheKey, parsedResponse.fact);
            }
        } catch(e) {
            console.error(`Failed to fetch food fact for ${stateName}:`, e);
            // Don't set a user-facing error for this, just fail silently.
        } finally {
            setIsLoadingFact(false);
        }
    }, [stateName, apiCache, updateApiCache]);

    useEffect(() => {
        fetchDishesForState();
        fetchFoodFact();
    }, [fetchDishesForState, fetchFoodFact]);

    return (
        <div className="container mx-auto">
            <div className="text-center mb-10">
                <button onClick={onBack} className="text-lg font-semibold text-orange-600 hover:underline mb-4">&larr; Back to States</button>
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
                    Specialties of {stateName}
                </h2>
                <p className="mt-4 text-xl text-gray-600">Click on a dish to learn more.</p>
                {!isLoadingFact && foodFact && (
                    <div className="mt-6 max-w-2xl mx-auto p-4 bg-orange-100/80 rounded-lg text-lg text-gray-800 italic border border-orange-200/50" style={{ animation: 'fadeIn 0.5s ease-out' }}>
                        "{foodFact}"
                    </div>
                )}
            </div>
            
            {isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="bg-gray-200 rounded-xl h-24 p-6 shimmer-bg" />
                ))}
              </div>
            )}
            {error && <p className="text-red-500 text-center text-lg bg-red-50 p-4 rounded-lg" role="alert">{error}</p>}
            
            {!isLoading && !error && dishes.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {dishes.map((dish, index) => (
                        <button
                            key={dish}
                            onClick={() => onDishClick(dish, stateName)}
                            className="bg-white p-6 rounded-xl shadow-lg hover:bg-orange-100 hover:shadow-xl transform hover:-translate-y-2 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-orange-500 border border-gray-200 text-left"
                            style={{ animation: `fadeAndSlideUp 0.5s ease-out ${index * 0.05}s backwards` }}
                        >
                           <span className="font-bold text-xl text-gray-800">{dish}</span>
                        </button>
                    ))}
                </div>
            )}
            {!isLoading && !error && dishes.length === 0 && (
                 <div className="text-center py-10">
                    <p className="text-xl text-gray-500">No special dishes were found for this state.</p>
                </div>
            )}
            <style>{`.shimmer-bg {
                background: linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);
                background-size: 2000px 100%;
                animation: shimmer 1.5s infinite linear;
            }`}</style>
        </div>
    );
};

const SpecialDishes: React.FC<SpecialDishesProps> = ({ 
    onDishClick, 
    onStateSelect, 
    selectedState, 
    onBackToStates, 
    apiCache, 
    updateApiCache 
}) => {
    if (selectedState) {
        return <DishListView 
            stateName={selectedState} 
            onDishClick={onDishClick} 
            onBack={onBackToStates} 
            apiCache={apiCache}
            updateApiCache={updateApiCache}
        />;
    }
    
    return <StateListView onStateSelect={onStateSelect} />;
};

export default SpecialDishes;