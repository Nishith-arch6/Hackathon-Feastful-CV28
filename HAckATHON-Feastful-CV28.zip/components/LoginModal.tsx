
import React, { useState, useCallback } from 'react';
import { LoginStep } from '../types';
import EmailIcon from './icons/EmailIcon';
import LockIcon from './icons/LockIcon';
import UserIcon from './icons/UserIcon';

interface LoginModalProps {
  onClose: () => void;
  onLoginSuccess: (username: string) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onLoginSuccess }) => {
  const [step, setStep] = useState<LoginStep>(LoginStep.Email);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [profileName, setProfileName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const validateEmail = (email: string) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const handleNext = useCallback(() => {
    setError(null);
    if (step === LoginStep.Email) {
      if (!validateEmail(email)) {
        setError('Please enter a valid email address.');
        return;
      }
      setStep(LoginStep.Password);
    } else if (step === LoginStep.Password) {
      const hasUpperCase = /[A-Z]/.test(password);
      const hasNumber = /\d/.test(password);
      const hasSymbol = /[!@#$%^&*(),.?":{}|<>]/.test(password);
      
      if (password.length < 8 || !hasUpperCase || !hasNumber || !hasSymbol) {
        setError('Please create a strong password. It must be at least 8 characters and include an uppercase letter, a number, and a symbol.');
        return;
      }
      setStep(LoginStep.ProfileName);
    }
  }, [step, email, password]);

  const handleLogin = useCallback(() => {
    setError(null);
    if (profileName.trim().length < 3) {
      setError('Profile name must be at least 3 characters long.');
      return;
    }
    onLoginSuccess(profileName);
  }, [profileName, onLoginSuccess]);
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if(step === LoginStep.Email || step === LoginStep.Password) {
          handleNext();
      } else if (step === LoginStep.ProfileName) {
          handleLogin();
      }
    }
  };


  const renderStepContent = () => {
    switch (step) {
      case LoginStep.Email:
        return (
          <>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">Sign in</h3>
            <p className="text-gray-500 mb-6">to continue to Feastful</p>
            <div className="relative mb-4">
              <EmailIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full pl-12 pr-4 py-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                autoFocus
              />
            </div>
            <button onClick={handleNext} className="w-full bg-orange-500 text-white py-3 text-lg rounded-lg hover:bg-orange-600 transition-colors">Next</button>
          </>
        );
      case LoginStep.Password:
        return (
          <>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">Welcome</h3>
            <p className="text-gray-500 mb-6 flex items-center justify-center space-x-2">
                <EmailIcon className="w-5 h-5" />
                <span>{email}</span>
            </p>
            <div className="relative mb-4">
              <LockIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full pl-12 pr-4 py-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                autoFocus
              />
            </div>
            <button onClick={handleNext} className="w-full bg-orange-500 text-white py-3 text-lg rounded-lg hover:bg-orange-600 transition-colors">Next</button>
          </>
        );
      case LoginStep.ProfileName:
        return (
          <>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">One last step!</h3>
            <p className="text-gray-500 mb-6">Choose a name for your profile.</p>
            <div className="relative mb-4">
              <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
              <input
                type="text"
                placeholder="Profile Name"
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full pl-12 pr-4 py-3 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                autoFocus
              />
            </div>
            <button onClick={handleLogin} className="w-full bg-orange-500 text-white py-3 text-lg rounded-lg hover:bg-orange-600 transition-colors">Finish</button>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50"
      style={{ animation: 'fadeIn 0.3s ease' }}
      onClick={onClose}
    >
      <div 
        className="relative bg-orange-50 rounded-2xl shadow-2xl p-10 w-full max-w-md text-center"
        style={{ animation: 'popIn 0.4s ease-out' }}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-3xl">&times;</button>
        <div className="mb-6">
            <h2 className="text-3xl font-bold text-gray-800">Feastful</h2>
        </div>
        {error && <p className="text-red-500 text-base mb-4">{error}</p>}
        {renderStepContent()}
      </div>
    </div>
  );
};

export default LoginModal;