
import React, { useState, useEffect, useRef } from 'react';
import { FlxDish } from '../types';
import RupeeIcon from './icons/RupeeIcon';

interface FlxSliderProps {
    dishes: FlxDish[];
    showTitle?: boolean;
}

const FlxSlider: React.FC<FlxSliderProps> = ({ dishes, showTitle = true }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    const resetTimeout = () => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
    };

    useEffect(() => {
        // When the number of dishes changes (e.g., a new one is added),
        // reset the slider to the first slide to show the new item immediately.
        setCurrentIndex(0);
    }, [dishes.length]);

    useEffect(() => {
        resetTimeout();
        if (dishes.length > 1) { // Only run slideshow if there's more than one item
            timeoutRef.current = setTimeout(
                () => setCurrentIndex((prevIndex) => (prevIndex + 1) % dishes.length),
                5000 // Change slide every 5 seconds
            );
        }
        return () => {
            resetTimeout();
        };
    }, [currentIndex, dishes.length]);


    if (dishes.length === 0) {
        return null;
    }

    return (
        <div className="w-full max-w-5xl mx-auto">
            {showTitle && <h3 className="text-3xl font-bold text-gray-800 text-center mb-6">Today's Fresh Picks</h3>}
            <div className="relative overflow-hidden rounded-2xl shadow-xl border-2 border-gray-800 bg-orange-50">
                <div
                    className="flex transition-transform duration-700 ease-in-out"
                    style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                    {dishes.map((dish, index) => (
                        <div className="w-full flex-shrink-0" key={`${dish.name}-${index}`}>
                            <div className="flex flex-col md:flex-row items-center justify-center gap-x-12 gap-y-6 p-12 h-80">
                                {dish.image && (
                                    <div className="w-48 h-48 md:w-56 md:h-56 flex-shrink-0">
                                        <img src={dish.image} alt={dish.name} className="w-full h-full object-cover rounded-2xl shadow-lg" />
                                    </div>
                                )}
                                <div className={`flex flex-col justify-center text-center ${dish.image ? 'md:text-left' : ''}`}>
                                    <h4 className="text-4xl font-extrabold text-gray-800 tracking-tight">{dish.name}</h4>
                                    <p className="text-lg text-gray-600 mt-2">by {dish.sellerName}</p>
                                    <p className={`text-5xl font-bold text-green-600 flex items-center mt-6 ${dish.image ? 'justify-center md:justify-start' : 'justify-center'}`}>
                                        <RupeeIcon className="mr-2" />
                                        <span>{dish.price}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {dishes.length > 1 && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                        {dishes.map((_, index) => (
                            <button
                                key={index}
                                onClick={() => setCurrentIndex(index)}
                                className={`w-3 h-3 rounded-full transition-colors ${currentIndex === index ? 'bg-orange-600' : 'bg-orange-300'}`}
                                aria-label={`Go to slide ${index + 1}`}
                            ></button>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default FlxSlider;
