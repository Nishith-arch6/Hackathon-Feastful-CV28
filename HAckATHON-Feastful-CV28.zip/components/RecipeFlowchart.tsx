import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { RecipeStep } from '../types';

interface RecipeFlowchartProps {
  dishName: string;
  stateName: string;
  onBack: () => void;
  apiCache: Record<string, any>;
  updateApiCache: (key: string, value: any) => void;
}

const RecipeFlowchart: React.FC<RecipeFlowchartProps> = ({ dishName, stateName, onBack, apiCache, updateApiCache }) => {
  const [steps, setSteps] = useState<RecipeStep[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRecipe = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const cacheKey = `recipe_${stateName}_${dishName}`;

    if (apiCache[cacheKey]) {
      setSteps(apiCache[cacheKey]);
      setIsLoading(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const schema = {
        type: Type.OBJECT,
        properties: {
          recipe: {
            type: Type.ARRAY,
            description: "A step-by-step recipe.",
            items: {
              type: Type.OBJECT,
              properties: {
                step: { type: Type.INTEGER, description: "The step number." },
                instruction: { type: Type.STRING, description: "Detailed instruction for this step." },
                time: { type: Type.STRING, description: "Estimated time for this step, e.g., '5-7 minutes'." },
                ingredients: {
                  type: Type.ARRAY,
                  description: "List of ingredients used in this specific step.",
                  items: { type: Type.STRING }
                }
              },
              required: ["step", "instruction", "time", "ingredients"]
            }
          }
        },
        required: ["recipe"]
      };

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Generate a detailed step-by-step recipe flowchart to cook ${dishName} from ${stateName}, India. For each step, provide the step number, a clear instruction, the estimated time, and a list of ingredients specifically used in that step.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      });

      const responseText = response.text.trim();
      const parsedResponse = JSON.parse(responseText);

      if (parsedResponse && parsedResponse.recipe) {
        setSteps(parsedResponse.recipe);
        updateApiCache(cacheKey, parsedResponse.recipe);
      } else {
        setError("Could not generate the recipe steps. The AI's response was not in the expected format.");
      }
    } catch (e) {
      console.error(e);
      setError("Sorry, an error occurred while creating the recipe. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  }, [dishName, stateName, apiCache, updateApiCache]);

  useEffect(() => {
    fetchRecipe();
  }, [fetchRecipe]);
  
  return (
    <div className="container mx-auto max-w-5xl w-full">
      <div className="bg-orange-50 p-10 rounded-2xl shadow-xl">
        <div className="flex justify-between items-center mb-10 border-b-2 border-orange-200 pb-6">
          <div className="flex flex-col">
            <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight">How to make {dishName}</h2>
            <p className="text-xl text-gray-500 mt-2">A step-by-step guide</p>
          </div>
          <button onClick={onBack} className="px-8 py-3 text-lg font-semibold text-black bg-orange-500 rounded-lg hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors">
            &larr; Back to Dish
          </button>
        </div>

        {isLoading && (
          <div className="flex flex-col items-center justify-center h-64">
            <svg className="animate-spin h-16 w-16 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-6 text-lg text-gray-600">Generating your cooking guide...</p>
          </div>
        )}

        {error && <p className="text-red-500 text-center text-lg p-8 bg-red-50 rounded-lg" role="alert">{error}</p>}
        
        {!isLoading && !error && steps.length > 0 && (
          <div className="relative pl-8 border-l-2 border-orange-300">
            {steps.map((step, index) => (
              <div key={step.step} className="mb-12 relative">
                <div className="absolute flex items-center justify-center w-12 h-12 bg-orange-500 rounded-full left-[-2.7rem] top-0 border-4 border-orange-50">
                  <span className="text-xl font-bold text-white">{step.step}</span>
                </div>
                <div className="ml-8 bg-white p-6 rounded-lg shadow-md border border-gray-200">
                  <div className="flex justify-between items-start mb-4">
                    <p className="text-2xl font-bold text-gray-800 flex-1">{step.instruction}</p>
                    <div className="ml-6 flex items-center gap-2 text-lg font-semibold text-orange-600 bg-orange-100 px-3 py-1 rounded-full whitespace-nowrap">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.414-1.414L11 10.586V7z" clipRule="evenodd" /></svg>
                      <span>{step.time}</span>
                    </div>
                  </div>
                  {step.ingredients && step.ingredients.length > 0 && (
                    <div>
                      <h4 className="font-bold text-lg text-gray-600">Ingredients for this step:</h4>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {step.ingredients.map((ing, i) => (
                          <span key={i} className="bg-gray-200 text-gray-700 text-sm font-medium px-3 py-1 rounded-full">{ing}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RecipeFlowchart;
