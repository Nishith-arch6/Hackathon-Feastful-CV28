
import React from 'react';

interface HorizontalNavProps {
  onHomeClick: () => void;
  onExploreClick: () => void;
  onAboutClick: () => void;
  onFlxClick: () => void;
  onAwarenessClick: () => void;
  onChefsChallengeClick: () => void;
}

const HorizontalNav: React.FC<HorizontalNavProps> = ({ onHomeClick, onExploreClick, onAboutClick, onFlxClick, onAwarenessClick, onChefsChallengeClick }) => {
  const buttonClasses = "relative bg-white text-orange-700 font-semibold text-lg py-4 px-6 rounded-xl transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1 active:scale-95 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 focus:ring-offset-orange-100 border border-gray-800/20 overflow-hidden";

  return (
    <nav className="w-full bg-orange-100/80 backdrop-blur-sm">
      <div className="container mx-auto px-6 py-5">
        <ul className="flex flex-wrap justify-center items-center gap-x-6 gap-y-4">
          <li>
            <button
              onClick={onHomeClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="Go to homepage"
            >
              Home
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
          <li>
            <button
              onClick={onAboutClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="About Feastful"
            >
              About
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
          <li>
            <button
              onClick={onExploreClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="Explore the taste"
            >
              Explore the taste
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
          <li>
            <button
              onClick={onFlxClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="FLX section"
            >
              FLX
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
          <li>
            <button
              onClick={onChefsChallengeClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="Chef's Challenge"
            >
              Chef's Challenge
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
          <li>
            <button
              onClick={onAwarenessClick}
              className={`${buttonClasses} hover:bg-orange-50`}
              aria-label="Awareness of food"
            >
              Awareness of food
              <span className="absolute inset-0 border-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ boxShadow: '0 0 15px 5px rgba(249, 115, 22, 0.4)' }}></span>
            </button>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default HorizontalNav;