import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";

interface FoodFacts {
  foodWasteFacts: string[];
  foodImportanceFacts: string[];
}

interface FoodAwarenessProps {
    apiCache: Record<string, any>;
    updateApiCache: (key: string, value: any) => void;
}

const FoodAwareness: React.FC<FoodAwarenessProps> = ({ apiCache, updateApiCache }) => {
  const [facts, setFacts] = useState<FoodFacts | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchFacts = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    const cacheKey = 'food_facts';
    if(apiCache[cacheKey]) {
        setFacts(apiCache[cacheKey]);
        setIsLoading(false);
        return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

      const schema = {
        type: Type.OBJECT,
        properties: {
          foodWasteFacts: {
            type: Type.ARRAY,
            description: 'A list of 3-5 impactful facts about global food waste.',
            items: { type: Type.STRING }
          },
          foodImportanceFacts: {
            type: Type.ARRAY,
            description: 'A list of 3-5 insightful facts about the importance of food for health, culture, and well-being.',
            items: { type: Type.STRING }
          }
        },
        required: ['foodWasteFacts', 'foodImportanceFacts']
      };

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: "Generate some interesting and impactful facts about food. Provide facts about food waste and also facts about the importance of food for human life and health.",
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      });

      const responseText = response.text.trim();
      const parsedFacts = JSON.parse(responseText);
      setFacts(parsedFacts);
      updateApiCache(cacheKey, parsedFacts);

    } catch (e) {
      console.error(e);
      setError('Sorry, I couldn\'t fetch the facts right now. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }, [apiCache, updateApiCache]);

  useEffect(() => {
    fetchFacts();
  }, [fetchFacts]);

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-64">
          <svg className="animate-spin h-16 w-16 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="mt-6 text-lg text-gray-600">Gathering some food for thought...</p>
        </div>
      );
    }

    if (error) {
      return <p className="text-red-500 text-center text-lg" role="alert">{error}</p>;
    }

    if (facts) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 animate-fade-in">
          <div className="bg-orange-50 p-10 rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-gray-800 mb-6 border-b-2 border-orange-200 pb-4">The Reality of Food Waste</h3>
            <ul className="list-disc list-inside space-y-5 text-xl text-gray-700">
              {facts.foodWasteFacts.map((fact, index) => <li key={`waste-${index}`}>{fact}</li>)}
            </ul>
          </div>
          <div className="bg-orange-50 p-10 rounded-2xl shadow-lg">
            <h3 className="text-4xl font-bold text-gray-800 mb-6 border-b-2 border-orange-200 pb-4">Why Food Matters</h3>
            <ul className="list-disc list-inside space-y-5 text-xl text-gray-700">
              {facts.foodImportanceFacts.map((fact, index) => <li key={`importance-${index}`}>{fact}</li>)}
            </ul>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="container mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
          Food for Thought
        </h2>
        <p className="mt-6 text-2xl text-gray-600">
          Understanding our relationship with food.
        </p>
      </div>
      {renderContent()}
      <style>{`
        .animate-fade-in {
          animation: fadeIn 0.5s ease-in-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default FoodAwareness;