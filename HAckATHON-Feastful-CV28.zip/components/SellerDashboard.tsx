
import React from 'react';
import { OrderNotification } from '../types';
import OrderNotificationItem from './OrderNotificationItem';

interface SellerDashboardProps {
    notifications: OrderNotification[];
    onUpdateNotifications: (notifications: OrderNotification[]) => void;
}

const SellerDashboard: React.FC<SellerDashboardProps> = ({ notifications, onUpdateNotifications }) => {
    
    const handleUpdate = (updatedOrder: OrderNotification) => {
        const updatedList = notifications.map(n => n.id === updatedOrder.id ? updatedOrder : n);
        onUpdateNotifications(updatedList);
    };
    
    const statusOrder = { 'pending': 1, 'accepted': 2, 'out_for_delivery': 3 };
    
    const liveNotifications = notifications
      .filter(n => n.status === 'pending' || n.status === 'accepted' || n.status === 'out_for_delivery')
      .sort((a, b) => {
          const orderA = statusOrder[a.status] || 99;
          const orderB = statusOrder[b.status] || 99;
          if (orderA !== orderB) {
              return orderA - orderB;
          }
          return new Date(a.orderDate).getTime() - new Date(b.orderDate).getTime();
      });

    return (
        <div>
            <div className="text-center mb-10">
                <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
                    Seller Dashboard
                </h2>
                <p className="mt-4 text-xl text-gray-600">Manage your incoming orders.</p>
            </div>

            <div className="bg-orange-50 p-8 rounded-2xl shadow-xl border-2 border-gray-800">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-3xl font-bold text-gray-800">Live Orders</h3>
                </div>
                <div className="space-y-4">
                    {liveNotifications.length > 0 ? (
                        liveNotifications.map(order => (
                            <OrderNotificationItem
                                key={order.id}
                                order={order}
                                onUpdate={handleUpdate}
                            />
                        ))
                    ) : (
                        <div className="text-center py-10">
                            <p className="text-xl text-gray-500">You have no active orders at the moment.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default SellerDashboard;
