import React from 'react';

const SkeletonCard: React.FC = () => {
    return (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <div className="h-48 bg-gray-200 shimmer-bg"></div>
            <div className="p-6">
                <div className="h-6 w-3/4 bg-gray-200 rounded shimmer-bg mb-4"></div>
                <div className="h-4 w-full bg-gray-200 rounded shimmer-bg mb-2"></div>
                <div className="h-4 w-5/6 bg-gray-200 rounded shimmer-bg mb-6"></div>
                <div className="space-y-4 pt-4 border-t border-gray-200">
                    <div className="h-5 w-1/2 bg-gray-200 rounded shimmer-bg"></div>
                    <div className="h-5 w-1/3 bg-gray-200 rounded shimmer-bg"></div>
                    <div className="h-5 w-1/2 bg-gray-200 rounded shimmer-bg"></div>
                </div>
                <div className="mt-6 h-12 w-full bg-gray-200 rounded-lg shimmer-bg"></div>
            </div>
            <style>{`.shimmer-bg {
                background: linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);
                background-size: 2000px 100%;
                animation: shimmer 1.5s infinite linear;
            }`}</style>
        </div>
    );
};

export default SkeletonCard;
