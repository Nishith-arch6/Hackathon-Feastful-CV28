
import React from 'react';
import { FlxDish } from '../types';
import FlxSlider from './FlxSlider';

interface WelcomeProps {
    flxDishes: FlxDish[];
    isDashboardView?: boolean;
}

const Welcome: React.FC<WelcomeProps> = ({ flxDishes, isDashboardView = false }) => {
    return (
        <div className="text-center">
            {!isDashboardView ? (
                <>
                    <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl" style={{ animation: 'fadeAndSlideUp 0.6s ease-out' }}>
                        Welcome to Feastful
                    </h2>
                    <p className="mt-6 text-2xl text-gray-600 max-w-3xl mx-auto" style={{ animation: 'fadeAndSlideUp 0.8s ease-out' }}>
                        Your journey into culinary delights starts here. Explore taste, discover fresh meals, or learn about food awareness.
                    </p>
                </>
            ) : (
                <div className="text-center mb-10">
                    <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl" style={{ animation: 'fadeAndSlideUp 0.6s ease-out' }}>
                        Today's Fresh Picks
                    </h2>
                    <p className="mt-4 text-xl text-gray-600" style={{ animation: 'fadeAndSlideUp 0.8s ease-out' }}>Freshly made, ready to go!</p>
                </div>
            )}
            
            {flxDishes.length > 0 && (
                <div className={!isDashboardView ? 'mt-16' : ''} style={{ animation: 'fadeIn 1s ease-out 0.5s backwards' }}>
                    <FlxSlider 
                        dishes={flxDishes} 
                        showTitle={!isDashboardView}
                    />
                </div>
            )}
        </div>
    );
};

export default Welcome;