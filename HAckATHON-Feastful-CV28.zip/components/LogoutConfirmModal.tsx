import React from 'react';

interface LogoutConfirmModalProps {
  onConfirm: () => void;
  onCancel: () => void;
}

const LogoutConfirmModal: React.FC<LogoutConfirmModalProps> = ({ onConfirm, onCancel }) => {
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50"
      style={{ animation: 'fadeIn 0.3s ease' }}
      onClick={onCancel}
    >
      <div 
        className="bg-orange-50 rounded-2xl shadow-2xl p-10 w-full max-w-lg text-center"
        style={{ animation: 'popIn 0.4s ease-out' }}
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-2xl font-semibold text-gray-700 mb-4">Are you sure you want to leave?</h3>
        <p className="text-lg text-gray-500 mb-8">You will be logged out of your account.</p>
        <div className="flex justify-center gap-6">
          <button 
            onClick={onCancel}
            className="px-10 py-4 text-xl font-semibold text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-all duration-200 transform hover:scale-105"
          >
            Stay
          </button>
          <button 
            onClick={onConfirm}
            className="px-10 py-4 text-xl font-semibold text-white bg-red-500 rounded-lg hover:bg-red-600 transition-all duration-200 transform hover:scale-105"
          >
            Leave
          </button>
        </div>
      </div>
    </div>
  );
};

export default LogoutConfirmModal;