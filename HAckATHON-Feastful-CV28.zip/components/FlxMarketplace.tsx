

import React from 'react';
import { FlxDish } from '../types';
import StorefrontIcon from './icons/StorefrontIcon';
import RupeeIcon from './icons/RupeeIcon';
import ClockIcon from './icons/ClockIcon';
import CartIcon from './icons/CartIcon';
import PlusIcon from './icons/PlusIcon';
import SkeletonCard from './SkeletonCard';

interface FlxMarketplaceProps {
  dishes: FlxDish[];
  isLoading: boolean;
  onDishSelect: (dish: FlxDish) => void;
  onAddToCart: (dish: FlxDish) => void;
  onAddItemClick: () => void;
}

const FlxMarketplace: React.FC<FlxMarketplaceProps> = ({ dishes, isLoading, onDishSelect, onAddToCart, onAddItemClick }) => {

  const handleCardClick = (dish: FlxDish) => {
    onDishSelect(dish);
  };

  const handleAddToCartClick = (e: React.MouseEvent<HTMLButtonElement>, dish: FlxDish) => {
    e.stopPropagation(); 
    onAddToCart(dish);
    const button = e.currentTarget;
    button.style.animation = 'bounceClick 0.3s ease-out';
    setTimeout(() => {
        button.style.animation = '';
    }, 300);
  };

  return (
    <div className="container mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight sm:text-6xl">
          FLX Marketplace
        </h2>
        <p className="mt-6 text-2xl text-gray-600">
          Freshly Made, Ready to Go!
        </p>
      </div>

      <div className="mb-10 text-center" style={{ animation: 'fadeIn 0.5s ease-out' }}>
          <button
              onClick={onAddItemClick}
              className="inline-flex items-center gap-2 px-6 py-3 text-xl font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors shadow-md hover:shadow-lg transform hover:-translate-y-1 active:scale-95"
              aria-label="Add a new dish to the marketplace"
          >
              <PlusIcon className="w-6 h-6" />
              Add the dish
          </button>
      </div>

      {isLoading && dishes.length === 0 && (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
            {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
         </div>
      )}

      {dishes.length === 0 && !isLoading && (
        <p className="text-red-500 text-center text-lg" role="alert">No dishes available at the moment.</p>
      )}

      {!isLoading && dishes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
          {dishes.map((dish, index) => (
            <div key={`${dish.name}-${index}`}
                className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-all duration-300 ease-in-out hover:shadow-2xl flex flex-col border border-gray-200 group"
                 style={{ animation: `fadeAndSlideUp 0.5s ease-out ${index * 0.1}s backwards` }}
            >
                {dish.image && (
                  <div className="overflow-hidden h-48">
                    <img src={dish.image} alt={dish.name} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                  </div>
                )}
                <div onClick={() => handleCardClick(dish)} className="p-6 flex-grow flex flex-col cursor-pointer">
                    <h3 className="text-2xl font-bold text-gray-800 mb-2 group-hover:text-orange-600 transition-colors">{dish.name}</h3>
                    <p className="text-gray-600 text-base mb-4 flex-grow">{dish.description}</p>
                    
                    <div className="space-y-3 text-lg mt-auto pt-4 border-t border-gray-200">
                        <div className="flex items-center text-gray-700">
                            <StorefrontIcon className="w-6 h-6 mr-3 text-orange-500" />
                            <span className="truncate">By: {dish.sellerName}</span>
                        </div>
                        <div className="flex items-center text-green-600 font-semibold">
                            <RupeeIcon className="mr-2" />
                            <span>{dish.price}</span>
                        </div>
                        <div className="flex items-center text-gray-500">
                            <ClockIcon className="w-6 h-6 mr-3 text-orange-500" />
                            <span className="truncate">{dish.availableUntil}</span>
                        </div>
                    </div>
                </div>
                <div className="px-6 pb-6">
                    <button 
                        onClick={(e) => handleAddToCartClick(e, dish)}
                        className="w-full flex items-center justify-center gap-2 bg-orange-600 text-white font-bold py-3 rounded-lg hover:bg-orange-700 transition-all duration-200 transform hover:scale-105"
                    >
                        <CartIcon className="w-5 h-5" />
                        Add to Cart
                    </button>
                </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FlxMarketplace;
