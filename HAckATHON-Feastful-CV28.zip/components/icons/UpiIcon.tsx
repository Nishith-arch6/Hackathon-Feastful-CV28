import React from 'react';

const UpiIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.353-.026.715-.026 1.068 0 1.13.094 1.976 1.057 1.976 2.192V7.5M8.25 7.5h7.5M8.25 7.5V9c0 .414.336.75.75.75h6c.414 0 .75-.336.75-.75V7.5m-7.5 0h7.5M6 10.5v8.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V10.5" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 12.75h4.5m-4.5 3h4.5" />
  </svg>
);

export default UpiIcon;
