import React from 'react';

const FlameIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M13.46,2.11L10.3,5.63C9.3,10.05 12.85,16.05 12.85,16.05C12.85,16.05 17.11,10.46 17.5,7.6C17.78,5.43 16.27,3.13 13.46,2.11M7.17,17.1C7.17,17.1 8.5,18.54 8.5,20.44C8.5,22.33 6.94,22.95 6,21.94C5.06,20.94 5.67,19.33 5.67,19.33S6.17,17.88 7.17,17.1Z" />
    </svg>
);

export default FlameIcon;
