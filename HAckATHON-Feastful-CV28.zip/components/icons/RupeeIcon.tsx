import React from 'react';

const RupeeIcon: React.FC<React.HTMLAttributes<HTMLSpanElement>> = (props) => {
    // The rupee symbol is best represented as text for accessibility and scaling.
    return (
        <span {...props}>
            ₹
        </span>
    );
};

export default RupeeIcon;
