
import React from 'react';

const ChefHatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    {...props}
  >
    <path d="M12.01,2.05C9.25,2.05 7,4.3 7,7.06V12.06H4V14.06H5.08C5.5,16.21 7.21,17.88 9.33,18.06V22.06H14.67V18.06C16.79,17.88 18.5,16.21 18.92,14.06H20V12.06H17V7.06C17,4.3 14.75,2.05 12.01,2.05M9,12.06V7.06C9,5.41 10.34,4.06 12,4.06C13.66,4.06 15,5.41 15,7.06V12.06H9Z" />
  </svg>
);

export default ChefHatIcon;
