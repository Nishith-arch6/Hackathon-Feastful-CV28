
import React from 'react';

const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={2}
    stroke="currentColor"
    {...props}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5v.75c0 .71-.215 1.41-.62 2.002a9.041 9.041 0 00-2.861 2.4c-.723.384-1.35.956-1.653 1.715a4.498 4.498 0 01-.322 1.672v3.75a.75.75 0 01-.75.75A2.25 2.25 0 016.75 15v-3.75a.75.75 0 00-.75-.75H3.75A2.25 2.25 0 011.5 8.25V6a2.25 2.25 0 012.25-2.25h2.25a.75.75 0 01.75.75v3.75z"
    />
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M21 8.25V19.5a2.25 2.25 0 01-2.25 2.25H18a2.25 2.25 0 01-2.25-2.25V8.25A2.25 2.25 0 0118 6h.75A2.25 2.25 0 0121 8.25z"
    />
  </svg>
);

export default TruckIcon;
