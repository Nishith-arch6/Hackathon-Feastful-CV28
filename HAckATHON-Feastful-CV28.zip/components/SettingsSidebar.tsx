
import React, { useState, useEffect } from 'react';
import { SellerDetails } from '../types';

interface SettingsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  isSellerMode: boolean;
  setIsSellerMode: (isSeller: boolean) => void;
  sellerDetails: SellerDetails | null;
  onSaveSellerDetails: (details: SellerDetails) => void;
  onHistoryClick: () => void;
}

const SettingsSidebar: React.FC<SettingsSidebarProps> = ({ 
  isOpen, 
  onClose, 
  isSellerMode, 
  setIsSellerMode, 
  sellerDetails,
  onSaveSellerDetails,
  onHistoryClick
}) => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    if (sellerDetails) {
      setEmail(sellerDetails.email);
      setPhone(sellerDetails.phone);
      setAddress(sellerDetails.address);
    } else {
      setEmail('');
      setPhone('');
      setAddress('');
    }
  }, [sellerDetails]);

  const handleSave = () => {
    if (email && phone && address) {
      onSaveSellerDetails({ email, phone, address });
    }
  };

  return (
    <div
      className={`fixed inset-0 z-50 transition-all duration-300 ease-in-out ${
        isOpen ? 'bg-black bg-opacity-50' : 'pointer-events-none'
      }`}
      onClick={onClose}
    >
      <div
        className={`absolute top-0 right-0 h-full w-full max-w-md bg-orange-50 shadow-2xl transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8 h-full flex flex-col">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-4xl font-bold text-gray-800">Settings</h2>
            <button onClick={onClose} className="text-5xl font-bold text-gray-400 hover:text-gray-600 leading-none">&times;</button>
          </div>
          
          <div className="space-y-8 flex-grow overflow-y-auto pr-2">
            <div className="p-4 bg-orange-100 rounded-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-3">Account</h3>
                <button 
                  onClick={onHistoryClick} 
                  className="w-full text-left p-3 rounded-lg hover:bg-orange-200 font-semibold text-xl text-gray-800 transition-colors"
                >
                  Order History
                </button>
            </div>

            <div className="p-4 bg-orange-100 rounded-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-3">Mode</h3>
                <div className="flex w-full rounded-lg bg-gray-300 p-1">
                    <button
                        onClick={() => setIsSellerMode(false)}
                        className={`w-1/2 rounded-md py-3 text-lg font-bold transition-colors ${
                            !isSellerMode ? 'bg-orange-500 text-white shadow-md' : 'bg-transparent text-gray-700 hover:bg-gray-200'
                        }`}
                        disabled={!sellerDetails}
                        title={!sellerDetails ? "Register as a seller to use this mode" : "Switch to Buyer Mode"}
                    >
                        Buyer
                    </button>
                    <button
                        onClick={() => setIsSellerMode(true)}
                        className={`w-1/2 rounded-md py-3 text-lg font-bold transition-colors ${
                            isSellerMode ? 'bg-orange-500 text-white shadow-md' : 'bg-transparent text-gray-700 hover:bg-gray-200'
                        }`}
                         disabled={!sellerDetails}
                         title={!sellerDetails ? "Register as a seller to use this mode" : "Switch to Seller Mode"}
                    >
                        Seller
                    </button>
                </div>
                {!sellerDetails && <p className="text-sm text-gray-500 mt-2 text-center">Register below to switch modes.</p>}
            </div>
            
            <div className="p-6 border-2 border-dashed border-orange-300 rounded-lg">
              {sellerDetails ? (
                 <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-4">Your Seller Details</h3>
                    <p className="text-lg text-gray-800"><strong className="font-semibold">Email:</strong> {sellerDetails.email}</p>
                    <p className="text-lg text-gray-800"><strong className="font-semibold">Phone:</strong> {sellerDetails.phone}</p>
                    <p className="text-lg text-gray-800"><strong className="font-semibold">Address:</strong> {sellerDetails.address}</p>
                 </div>
              ) : (
                <div className="space-y-4">
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">Become a Seller</h3>
                    <p className="text-gray-600 mb-4">Provide your details to start selling your delicious home-cooked meals.</p>
                    <div>
                        <label className="block text-lg font-semibold text-gray-700 mb-1">Email</label>
                        <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500"/>
                    </div>
                    <div>
                        <label className="block text-lg font-semibold text-gray-700 mb-1">Contact Number</label>
                        <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500"/>
                    </div>
                    <div>
                        <label className="block text-lg font-semibold text-gray-700 mb-1">Pickup Address</label>
                        <textarea value={address} onChange={e => setAddress(e.target.value)} className="w-full p-3 text-lg border border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500" rows={3}></textarea>
                    </div>
                    <button onClick={handleSave} className="w-full bg-orange-600 text-white font-bold py-3 rounded-lg hover:bg-orange-700">Save Details & Become a Seller</button>
                </div>
              )}
            </div>
          </div>

          <div className="mt-auto text-center text-gray-500 pt-4">
            <p className="text-sm">Feastful v1.0</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsSidebar;
