
import React, { useEffect } from 'react';
import CartIcon from './icons/CartIcon';
import BellIcon from './icons/BellIcon';

interface ToastProps {
    message: string;
    type: 'success' | 'error' | 'info';
    onClear: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClear }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClear();
        }, 5000); // Changed from 3000 to 5000

        return () => {
            clearTimeout(timer);
        };
    }, [onClear]);

    const toastConfig = {
        success: {
            bg: 'bg-green-600',
            icon: <CartIcon className="w-6 h-6" />
        },
        error: {
            bg: 'bg-red-600',
            icon: (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            )
        },
        info: {
            bg: 'bg-blue-600',
            icon: <BellIcon className="w-6 h-6" />
        }
    };

    const currentStyle = toastConfig[type] || toastConfig.info;

    return (
        <div 
            className={`fixed bottom-10 right-10 text-white text-lg font-semibold py-4 px-6 rounded-lg shadow-2xl flex items-center gap-4 z-50 animate-toast-in ${currentStyle.bg}`}
            role="alert"
        >
            {currentStyle.icon}
            <span>{message}</span>
            <style>{`
                @keyframes toast-in {
                    0% {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    100% {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                .animate-toast-in {
                    animation: toast-in 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;
                }
            `}</style>
        </div>
    );
};

export default Toast;
