
import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import FlameIcon from './icons/FlameIcon';

interface DishDetailProps {
  dishName: string;
  stateName: string;
  onBack: () => void;
  onBurnTheFlame: () => void;
  apiCache: Record<string, any>;
  updateApiCache: (key: string, value: any) => void;
}

const DishDetail: React.FC<DishDetailProps> = ({ dishName, stateName, onBack, onBurnTheFlame, apiCache, updateApiCache }) => {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [isLoadingIngredients, setIsLoadingIngredients] = useState(true);
  const [ingredientsError, setIngredientsError] = useState<string | null>(null);

  const fetchIngredients = useCallback(async () => {
    setIsLoadingIngredients(true);
    setIngredientsError(null);

    const cacheKey = `ingredients_${stateName}_${dishName}`;
    if (apiCache[cacheKey]) {
      setIngredients(apiCache[cacheKey]);
      setIsLoadingIngredients(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const schema = {
        type: Type.OBJECT,
        properties: {
          ingredients: {
            type: Type.ARRAY,
            description: 'A list of key ingredients for the dish.',
            items: { type: Type.STRING }
          }
        },
        required: ['ingredients']
      };

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `List the main ingredients needed to cook ${dishName} from ${stateName}, India.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      });

      const responseText = response.text.trim();
      const parsedResponse = JSON.parse(responseText);

      if (parsedResponse && parsedResponse.ingredients) {
        setIngredients(parsedResponse.ingredients);
        updateApiCache(cacheKey, parsedResponse.ingredients);
      } else {
        setIngredientsError('Could not find ingredients for this dish.');
      }
    } catch (e) {
      console.error(e);
      setIngredientsError('Sorry, an error occurred while fetching ingredients.');
    } finally {
      setIsLoadingIngredients(false);
    }
  }, [dishName, stateName, apiCache, updateApiCache]);

  useEffect(() => {
    fetchIngredients();
  }, [fetchIngredients]);

  const handleBurnClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const button = e.currentTarget;
    button.style.animation = 'bounceClick 0.4s ease-out';
    setTimeout(() => {
        button.style.animation = '';
        onBurnTheFlame();
    }, 400);
  }

  return (
    <div className="container mx-auto max-w-4xl w-full">
      <div className="bg-orange-50 p-10 rounded-2xl shadow-xl" style={{ animation: 'fadeAndSlideUp 0.5s ease-out' }}>
        <div className="flex justify-between items-center mb-8">
            <h2 className="text-5xl font-extrabold text-gray-800 tracking-tight">
                {dishName}
            </h2>
            <button
                onClick={onBack}
                className="px-8 py-3 text-lg font-semibold text-black bg-orange-400/80 rounded-lg hover:bg-orange-500 transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50"
            >
                &larr; Back
            </button>
        </div>

        <div className="bg-orange-100/80 p-8 rounded-lg flex flex-col">
          <h3 className="text-3xl font-bold text-gray-800 mb-6">Ingredients</h3>
          <div className='flex-grow min-h-[200px]'>
            {isLoadingIngredients && (
              <div className="flex items-center space-x-4">
                <svg className="animate-spin h-8 w-8 text-orange-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="text-lg text-gray-600">Looking for ingredients...</p>
              </div>
            )}
            {ingredientsError && <p className="text-red-500 text-lg" role="alert">{ingredientsError}</p>}
            {!isLoadingIngredients && !ingredientsError && ingredients.length > 0 && (
              <ul className="space-y-3 list-disc list-inside text-xl text-gray-700" style={{ animation: 'fadeIn 0.5s ease-out' }}>
                {ingredients.map((item, index) => <li key={index}>{item}</li>)}
              </ul>
            )}
          </div>
           <div className="mt-8">
              <button
                onClick={handleBurnClick}
                className="w-full flex items-center justify-center gap-3 bg-red-600 text-white text-xl font-bold py-4 rounded-lg hover:bg-red-700 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
              >
                <FlameIcon className="w-6 h-6" />
                Burn the Flame
              </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DishDetail;