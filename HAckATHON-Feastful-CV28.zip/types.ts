

export enum LoginStep {
  Email,
  Password,
  ProfileName,
}

export interface FlxDish {
  name: string;
  description: string;
  price: number;
  sellerName: string;
  availableUntil: string;
  image?: string;
  isUserAdded?: boolean;
}

export interface RecipeStep {
  step: number;
  instruction: string;
  time: string;
  ingredients: string[];
}

export interface CartItem extends FlxDish {
  quantity: number;
}

export interface SellerDetails {
  email: string;
  phone: string;
  address: string;
}

export interface OrderNotification {
  id: string;
  customerName: string;
  address: string;
  items: CartItem[];
  total: number;
  paymentMethod: string;
  status: 'pending' | 'accepted' | 'rejected' | 'out_for_delivery' | 'delivered';
  orderDate: string;
  review?: {
    rating: number;
    description: string;
  };
}

export interface GeneratedRecipe {
  recipeName: string;
  description: string;
  ingredients: string[];
  instructions: string[];
}