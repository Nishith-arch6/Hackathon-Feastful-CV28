
import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import LoginModal from './components/LoginModal';
import SloganBar from './components/SloganBar';
import HorizontalNav from './components/HorizontalNav';
import SpecialDishes from './components/SpecialDishes';
import Welcome from './components/Welcome';
import DishDetail from './components/DishDetail';
import FoodAwareness from './components/FoodAwareness';
import LogoutConfirmModal from './components/LogoutConfirmModal';
import SettingsSidebar from './components/SettingsSidebar';
import FlxMarketplace from './components/FlxMarketplace';
import FlxDishOrder from './components/FlxDishOrder';
import OrderConfirmation from './components/OrderConfirmation';
import RecipeFlowchart from './components/RecipeFlowchart';
import Cart from './components/Cart';
import Toast from './components/Toast';
import ChefsChallenge from './components/ChefsChallenge';
import { FlxDish, CartItem, SellerDetails, OrderNotification } from './types';
import { GoogleGenAI, Type } from "@google/genai";
import SellerDashboard from './components/SellerDashboard';
import AddFlxItem from './components/AddFlxItem';
import AboutPage from './components/AboutPage';
import MyOrders from './components/MyOrders';
import OrderTracker from './components/OrderTracker';
import History from './components/History';

type View = 'welcome' | 'dishes' | 'dishDetail' | 'awareness' | 'flxMarketplace' | 'flxDishOrder' | 'orderConfirmation' | 'recipeFlowchart' | 'cart' | 'chefsChallenge' | 'addFlxItem' | 'about' | 'myOrders' | 'orderTracker' | 'history';
type ToastType = 'success' | 'error' | 'info';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState<string | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [currentView, setCurrentView] = useState<View>('welcome');
  const [selectedDish, setSelectedDish] = useState<{ name: string; state: string } | null>(null);
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [selectedFlxDish, setSelectedFlxDish] = useState<FlxDish | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [apiCache, setApiCache] = useState<Record<string, any>>({});
  const [flxDishes, setFlxDishes] = useState<FlxDish[]>([]);
  const [isLoadingFlx, setIsLoadingFlx] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);
  const [isSellerMode, setIsSellerMode] = useState(false);
  const [sellerDetails, setSellerDetails] = useState<SellerDetails | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<ToastType>('info');
  const [notifications, setNotifications] = useState<OrderNotification[]>([]);
  const [myOrders, setMyOrders] = useState<OrderNotification[]>([]);
  const [selectedOrderForTracking, setSelectedOrderForTracking] = useState<OrderNotification | null>(null);

  const updateApiCache = useCallback((key: string, value: any) => {
    setApiCache(prevCache => ({ ...prevCache, [key]: value }));
  }, []);

  const fetchFlxDishes = useCallback(async () => {
    setIsLoadingFlx(true);
    const cacheKey = 'flx_dishes_v10_parallel'; // Updated cache key
    if(apiCache[cacheKey]) {
        setFlxDishes(apiCache[cacheKey]);
        setIsLoadingFlx(false);
        return;
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
        
        const schema = {
            type: Type.OBJECT,
            properties: {
              dishes: {
                type: Type.ARRAY,
                description: "A list of dishes for sale.",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "The name of the dish." },
                    description: { type: Type.STRING, description: "A short, tantalizing description of the dish." },
                    price: { type: Type.INTEGER, description: "The price of the dish in Indian Rupees." },
                    sellerName: { type: Type.STRING, description: "A fictional, traditional Indian housewife's name as the seller (e.g., 'Sita Devi', 'Lakshmi Amma', 'Parvati Menon')." },
                    availableUntil: { type: Type.STRING, description: "A short availability time, e.g., 'Until 8 PM'." }
                  },
                  required: ['name', 'description', 'price', 'sellerName', 'availableUntil']
                }
              }
            },
            required: ["dishes"]
          };
    
        const dishDetailsResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a list of 4 fictional, freshly prepared home-cooked Indian dishes available for sale in a marketplace. For each dish, provide a name, a short tantalizing description (1-2 sentences), a price in Indian Rupees (numeric), a fictional home-chef's name (sellerName) following the requested pattern, and a short availability time like 'Until 8 PM'.`,
            config: {
              responseMimeType: "application/json",
              responseSchema: schema,
            },
        });

        const parsedResponse = JSON.parse(dishDetailsResponse.text.trim());
        const initialDishes = (parsedResponse.dishes || []) as FlxDish[];
        
        // Show text-only dishes first for better perceived performance
        setFlxDishes(prevDishes => {
            const userAddedDishes = prevDishes.filter(d => d.isUserAdded);
            return [...userAddedDishes, ...initialDishes];
        });

        // Generate images in parallel for speed
        const imagePromises = initialDishes.map(dish => 
            ai.models.generateImages({
                model: 'imagen-3.0-generate-002',
                prompt: `A delicious, mouth-watering, home-cooked plate of authentic Indian ${dish.name}, beautifully presented in a home kitchen setting on a simple plate. The lighting should be warm and natural, giving a cozy and inviting feel. The photo should look like it was taken by a proud home chef, not a professional photographer. Centered in the frame.`,
                config: {
                    numberOfImages: 1,
                    outputMimeType: 'image/jpeg',
                    aspectRatio: '1:1',
                }
            }).then(response => ({
                name: dish.name,
                image: `data:image/jpeg;base64,${response.generatedImages[0].image.imageBytes}`
            })).catch(err => {
                console.error(`Failed to generate image for ${dish.name}:`, err);
                return { name: dish.name, image: undefined };
            })
        );
        
        const imageResults = await Promise.all(imagePromises);

        const dishesWithImages = initialDishes.map(dish => {
            const imageResult = imageResults.find(img => img.name === dish.name);
            return {
                ...dish,
                image: imageResult?.image,
            };
        });

        updateApiCache(cacheKey, dishesWithImages);
        // Final state update with images, preserving any user-added items
        setFlxDishes(prevDishes => {
            const userAddedDishes = prevDishes.filter(d => d.isUserAdded);
            return [...userAddedDishes, ...dishesWithImages];
        });

    } catch (e) {
        console.error("Failed to fetch FLX dishes:", e);
    } finally {
        setIsLoadingFlx(false);
    }
  }, [apiCache, updateApiCache]);
  
  useEffect(() => {
    // Only fetch if there are no dishes at all (neither user-added nor generated)
    if (flxDishes.length === 0) {
        fetchFlxDishes();
    }
  }, [fetchFlxDishes, flxDishes.length]);


  useEffect(() => {
    try {
      const savedDetails = localStorage.getItem('sellerDetails');
      const savedMode = localStorage.getItem('userMode');
      if (savedDetails) {
        setSellerDetails(JSON.parse(savedDetails));
        // Default to seller mode if details exist, but respect saved preference
        setIsSellerMode(savedMode === 'seller'); 
      }
    } catch (error) {
      console.error("Could not load seller details from localStorage", error);
    }
  }, []);

  useEffect(() => {
    // Only persist the mode for users who have completed seller registration.
    if(sellerDetails) {
        try {
            localStorage.setItem('userMode', isSellerMode ? 'seller' : 'buyer');
        } catch(e) {
            console.error("Could not save user mode", e);
        }
    }
  }, [isSellerMode, sellerDetails]);

  useEffect(() => {
    // This effect loads notifications if the user is a seller, regardless of the current mode.
    if (sellerDetails) {
      try {
        const storedNotifications = JSON.parse(localStorage.getItem('seller_notifications') || '[]') as OrderNotification[];
        setNotifications(storedNotifications);
      } catch (e) {
        console.error("Failed to load notifications", e);
        setNotifications([]);
      }
    } else {
      setNotifications([]);
    }
  }, [sellerDetails]);

  // Poll for new orders for SELLER
  useEffect(() => {
    if (!sellerDetails) return; // Only run for sellers

    const pollForNewOrders = () => {
        try {
            const storedNotificationsJSON = localStorage.getItem('seller_notifications') || '[]';
            const storedNotifications = JSON.parse(storedNotificationsJSON) as OrderNotification[];
            
            setNotifications(currentNotifications => {
                const existingIds = new Set(currentNotifications.map(n => n.id));
                const newOrders = storedNotifications.filter(n => !existingIds.has(n.id) && n.status === 'pending');

                if (newOrders.length > 0) {
                    const firstNewOrder = newOrders[0];
                    setToastMessage(`New Order #${firstNewOrder.id.slice(-4)} from ${firstNewOrder.customerName}!`);
                    setToastType('info');
                    return storedNotifications;
                }
                // Also update existing notifications for status changes
                return storedNotifications;
            });
        } catch (e) {
            console.error("Failed to poll for new orders", e);
        }
    };

    const intervalId = setInterval(pollForNewOrders, 5000); 

    return () => clearInterval(intervalId);
  }, [sellerDetails]);

   // Poll for order status updates for BUYER
  useEffect(() => {
    if (!isLoggedIn || !username) {
        setMyOrders([]);
        return;
    };

    const pollBuyerOrders = () => {
        try {
            // The single source of truth for orders is 'seller_notifications'
            const allOrdersJSON = localStorage.getItem('seller_notifications') || '[]';
            const allOrders = JSON.parse(allOrdersJSON) as OrderNotification[];
            
            // Filter orders belonging to the current user
            const currentUserOrders = allOrders.filter(o => o.customerName === username);

            setMyOrders(currentUserOrders);
            
            if (selectedOrderForTracking) {
                const updatedSelectedOrder = currentUserOrders.find(o => o.id === selectedOrderForTracking.id);
                if (updatedSelectedOrder) {
                    setSelectedOrderForTracking(updatedSelectedOrder);
                }
            }
        } catch (e) {
            console.error("Failed to poll for buyer order updates", e);
        }
    };

    const intervalId = setInterval(pollBuyerOrders, 5000);
    pollBuyerOrders(); // initial fetch

    return () => clearInterval(intervalId);
  }, [isLoggedIn, username, selectedOrderForTracking]);

  const handleUpdateNotifications = useCallback((updatedNotifications: OrderNotification[]) => {
      const rejectedOrder = updatedNotifications.find(updatedOrder => {
          const originalOrder = notifications.find(n => n.id === updatedOrder.id);
          return originalOrder && originalOrder.status !== 'rejected' && updatedOrder.status === 'rejected';
      });

      if (rejectedOrder) {
          setToastMessage(`Order #${rejectedOrder.id.slice(-4)} has been cancelled.`);
          setToastType('error');
      }

      setNotifications(updatedNotifications);
      try {
          localStorage.setItem('seller_notifications', JSON.stringify(updatedNotifications));
      } catch(e) {
          console.error("Failed to save updated notifications", e);
      }
  }, [notifications]);


  const handleLoginClick = useCallback(() => {
    setShowLoginModal(true);
  }, []);

  const handleCloseModal = useCallback(() => {
    setShowLoginModal(false);
  }, []);

  const handleLoginSuccess = useCallback((name: string) => {
    setUsername(name);
    setIsLoggedIn(true);
    setShowLoginModal(false);
  }, []);

  const handleLogoutRequest = useCallback(() => {
    setShowLogoutConfirm(true);
  }, []);

  const handleConfirmLogout = useCallback(() => {
    setIsLoggedIn(false);
    setUsername(null);
    setShowLogoutConfirm(false);
    setCart([]);
    setIsSellerMode(false);
    setSellerDetails(null);
    setMyOrders([]);
    setCurrentView('welcome');
    try {
      localStorage.removeItem('sellerDetails');
      localStorage.removeItem('userMode');
    } catch (error) {
        console.error("Could not remove seller details from localStorage", error);
    }
  }, []);

  const handleCancelLogout = useCallback(() => {
    setShowLogoutConfirm(false);
  }, []);
  
  const handleSettingsToggle = useCallback(() => {
    setIsSettingsOpen(prev => !prev);
  }, []);

  const handleSettingsClose = useCallback(() => {
    setIsSettingsOpen(false);
  }, []);

  const handleExploreClick = useCallback(() => {
    setCurrentView('dishes');
    setSelectedState(null);
    setSelectedDish(null);
  }, []);

  const handleAwarenessClick = useCallback(() => {
    setCurrentView('awareness');
  }, []);

  const handleHomeClick = useCallback(() => {
    setCurrentView('welcome');
    setSelectedDish(null);
    setSelectedFlxDish(null);
    setDeliveryAddress('');
    setOrderNumber(null);
    setSelectedOrderForTracking(null);
  }, []);

  const handleDishClick = useCallback((dishName: string, stateName: string) => {
    setSelectedDish({ name: dishName, state: stateName });
    setCurrentView('dishDetail');
  }, []);
  
  const handleStateSelect = useCallback((stateName: string) => {
    setSelectedState(stateName);
  }, []);
  
  const handleBackToStates = useCallback(() => {
    setSelectedState(null);
    setSelectedDish(null);
    setCurrentView('dishes');
  }, []);

  const handleBackToDishes = useCallback(() => {
    setCurrentView('dishes');
    setSelectedDish(null);
  }, []);

  const handleFlxDishSelect = useCallback((dish: FlxDish) => {
    setSelectedFlxDish(dish);
    setCurrentView('flxDishOrder');
  }, []);

  const handleBackToMarketplace = useCallback(() => {
    setCurrentView('flxMarketplace');
    setSelectedFlxDish(null);
  }, []);
  
  const handlePlaceCartOrder = useCallback((address: string, paymentMethod: string) => {
    if (address.trim() && cart.length > 0 && username) {
        setDeliveryAddress(address);
        const newOrderNumber = `FST-${Date.now().toString().slice(-6)}`;
        setOrderNumber(newOrderNumber);
        
        const newOrder: OrderNotification = {
          id: newOrderNumber,
          customerName: username,
          address,
          items: cart,
          total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
          paymentMethod,
          status: 'pending',
          orderDate: new Date().toISOString(),
        };
        
        setMyOrders(prev => [newOrder, ...prev]);

        try {
          const existingNotifications = JSON.parse(localStorage.getItem('seller_notifications') || '[]');
          localStorage.setItem('seller_notifications', JSON.stringify([newOrder, ...existingNotifications]));
        } catch (e) {
          console.error("Failed to save order notification", e);
        }

        setCurrentView('orderConfirmation');
        setCart([]);
    } else if (!username) {
        setToastMessage("Please log in to place an order.");
        setToastType("error");
        handleLoginClick();
    }
  }, [cart, username, handleLoginClick]);

  const handleAddToCart = useCallback((dish: FlxDish, quantity = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.name === dish.name);
      if (existingItem) {
        return prevCart.map(item =>
          item.name === dish.name
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevCart, { ...dish, quantity }];
    });
    setToastMessage(`Added ${dish.name} to cart!`);
    setToastType('success');
  }, []);

  const handleUpdateCart = useCallback((dishName: string, quantity: number) => {
    setCart(prevCart => {
        if(quantity <= 0) {
            return prevCart.filter(item => item.name !== dishName);
        }
        return prevCart.map(item =>
            item.name === dishName ? { ...item, quantity } : item
        );
    });
  }, []);

  const handleViewCart = useCallback(() => {
    setCurrentView('cart');
  }, []);

  const handleBurnTheFlame = useCallback((dishName: string, stateName: string) => {
    setSelectedDish({ name: dishName, state: stateName });
    setCurrentView('recipeFlowchart');
  }, []);

  const handleBackToDishDetail = useCallback(() => {
      if(selectedDish) {
        setCurrentView('dishDetail');
      } else {
        setCurrentView('dishes');
      }
  }, [selectedDish]);

  const handleFlxClick = useCallback(() => {
    setCurrentView('flxMarketplace');
  }, []);
  
  const handleSaveSellerDetails = useCallback((details: SellerDetails) => {
    try {
        localStorage.setItem('sellerDetails', JSON.stringify(details));
        setSellerDetails(details);
        setIsSellerMode(true); 
        setToastMessage("Seller details saved successfully!");
        setToastType('success');
    } catch (error) {
        console.error("Could not save seller details to localStorage", error);
        setToastMessage("Error: Could not save seller details.");
        setToastType('error');
    }
  }, []);

  const handleChefsChallengeClick = useCallback(() => {
    setCurrentView('chefsChallenge');
  }, []);

  const handleShowAddFlxItem = useCallback(() => {
    if (sellerDetails) {
      setCurrentView('addFlxItem');
    } else {
      setIsSettingsOpen(true);
      setToastMessage("Please register as a seller to add a dish.");
      setToastType('info');
    }
  }, [sellerDetails]);

  const handleAddItem = useCallback((newItem: FlxDish) => {
    const itemToAdd: FlxDish = { ...newItem, isUserAdded: true };
    setFlxDishes(prevDishes => [itemToAdd, ...prevDishes]);
    setCurrentView('welcome'); // back to seller dashboard
  }, []);

  const handleAboutClick = useCallback(() => {
    setCurrentView('about');
  }, []);

  const handleMyOrdersClick = useCallback(() => {
    setCurrentView('myOrders');
  }, []);

  const handleTrackOrderClick = useCallback((order: OrderNotification) => {
    setSelectedOrderForTracking(order);
    setCurrentView('orderTracker');
  }, []);

  const handleBackToMyOrders = useCallback(() => {
    setSelectedOrderForTracking(null);
    setCurrentView('myOrders');
  }, []);

  const handleHistoryClick = useCallback(() => {
    setCurrentView('history');
    handleSettingsClose();
  }, [handleSettingsClose]);

  const handleSaveReview = useCallback((orderId: string, rating: number, description: string) => {
    try {
        const allOrdersJSON = localStorage.getItem('seller_notifications') || '[]';
        const allOrders = JSON.parse(allOrdersJSON) as OrderNotification[];
        
        const updatedOrders = allOrders.map(order => {
            if (order.id === orderId) {
                return { ...order, review: { rating, description } };
            }
            return order;
        });

        localStorage.setItem('seller_notifications', JSON.stringify(updatedOrders));
        
        setMyOrders(prevOrders => prevOrders.map(order => 
            order.id === orderId ? { ...order, review: { rating, description } } : order
        ));

        setToastMessage("Thank you for your review!");
        setToastType('success');

    } catch (e) {
        console.error("Failed to save review", e);
        setToastMessage("Could not save your review.");
        setToastType('error');
    }
  }, []);

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const renderContent = () => {
    const animationWrapper = (content: React.ReactNode, key: string) => (
        <div key={key} style={{ animation: 'fadeAndSlideUp 0.5s ease-out' }}>
            {content}
        </div>
    );

    switch (currentView) {
      case 'dishes':
        return animationWrapper(<SpecialDishes 
                  onDishClick={handleDishClick}
                  onStateSelect={handleStateSelect}
                  selectedState={selectedState}
                  onBackToStates={handleBackToStates}
                  apiCache={apiCache}
                  updateApiCache={updateApiCache}
               />, 'dishes');
      case 'dishDetail':
        return selectedDish && animationWrapper(<DishDetail dishName={selectedDish.name} stateName={selectedDish.state} onBack={handleBackToDishes} onBurnTheFlame={() => handleBurnTheFlame(selectedDish.name, selectedDish.state)} apiCache={apiCache} updateApiCache={updateApiCache} />, 'dishDetail');
      case 'awareness':
        return animationWrapper(<FoodAwareness apiCache={apiCache} updateApiCache={updateApiCache} />, 'awareness');
      case 'flxMarketplace':
        return animationWrapper(<FlxMarketplace 
                  dishes={flxDishes} 
                  isLoading={isLoadingFlx} 
                  onDishSelect={handleFlxDishSelect} 
                  onAddToCart={handleAddToCart}
                  onAddItemClick={handleShowAddFlxItem}
                />, 'flxMarketplace');
      case 'flxDishOrder':
        return selectedFlxDish && animationWrapper(<FlxDishOrder dish={selectedFlxDish} onBack={handleBackToMarketplace} onAddToCart={handleAddToCart} />, 'flxDishOrder');
      case 'orderConfirmation':
        return animationWrapper(<OrderConfirmation address={deliveryAddress} orderNumber={orderNumber} onBackToHome={handleHomeClick} onViewOrders={handleMyOrdersClick} />, 'orderConfirmation');
      case 'recipeFlowchart':
        return selectedDish && animationWrapper(<RecipeFlowchart dishName={selectedDish.name} stateName={selectedDish.state} onBack={handleBackToDishDetail} apiCache={apiCache} updateApiCache={updateApiCache} />, 'recipeFlowchart');
      case 'cart':
        return animationWrapper(<Cart cartItems={cart} onUpdateCart={handleUpdateCart} onPlaceOrder={handlePlaceCartOrder} onBack={handleFlxClick} />, 'cart');
      case 'chefsChallenge':
        return animationWrapper(<ChefsChallenge apiCache={apiCache} updateApiCache={updateApiCache} />, 'chefsChallenge');
      case 'addFlxItem':
        return animationWrapper(<AddFlxItem onAddItem={handleAddItem} onBack={() => setCurrentView('welcome')} />, 'addFlxItem');
      case 'about':
        return animationWrapper(<AboutPage />, 'about');
      case 'myOrders':
        return animationWrapper(<MyOrders orders={myOrders} onTrackOrder={handleTrackOrderClick} onBack={handleFlxClick} />, 'myOrders');
      case 'orderTracker':
        return selectedOrderForTracking && animationWrapper(<OrderTracker order={selectedOrderForTracking} onBack={handleBackToMyOrders} />, 'orderTracker');
      case 'history':
        return animationWrapper(<History orders={myOrders} onSaveReview={handleSaveReview} onBack={handleHomeClick} />, 'history');
      case 'welcome':
      default:
        if (isSellerMode) {
          return animationWrapper(
            <div className="flex flex-col xl:flex-row gap-12 w-full justify-center">
              <div className="xl:w-1/2">
                <SellerDashboard 
                  notifications={notifications}
                  onUpdateNotifications={handleUpdateNotifications}
                />
              </div>
              <div className="xl:w-1/2 flex flex-col justify-center">
                <Welcome 
                  flxDishes={flxDishes}
                  isDashboardView={true}
                />
              </div>
            </div>
          , 'welcome-seller')
        }
        return animationWrapper(<Welcome 
                  flxDishes={flxDishes}
                />, 'welcome-buyer');
    }
  };

  return (
    <div className="min-h-screen flex flex-col antialiased">
      <Header 
        isLoggedIn={isLoggedIn} 
        username={username} 
        onLoginClick={handleLoginClick}
        onLogoutRequest={handleLogoutRequest}
        onHomeClick={handleHomeClick}
        onSettingsClick={handleSettingsToggle}
        onCartClick={handleViewCart}
        cartItemCount={cartItemCount}
        onMyOrdersClick={handleMyOrdersClick}
      />
      <SloganBar />
      <HorizontalNav 
        onHomeClick={handleHomeClick} 
        onExploreClick={handleExploreClick}
        onAboutClick={handleAboutClick}
        onAwarenessClick={handleAwarenessClick}
        onFlxClick={handleFlxClick}
        onChefsChallengeClick={handleChefsChallengeClick}
      />
      <main className="flex-grow container mx-auto px-6 py-12 flex justify-center items-start">
        {renderContent()}
      </main>

      {showLoginModal && <LoginModal onClose={handleCloseModal} onLoginSuccess={handleLoginSuccess} />}
      {showLogoutConfirm && <LogoutConfirmModal onConfirm={handleConfirmLogout} onCancel={handleCancelLogout} />}
      <SettingsSidebar 
        isOpen={isSettingsOpen} 
        onClose={handleSettingsClose}
        isSellerMode={isSellerMode}
        setIsSellerMode={setIsSellerMode}
        sellerDetails={sellerDetails}
        onSaveSellerDetails={handleSaveSellerDetails}
        onHistoryClick={handleHistoryClick}
      />
      {toastMessage && <Toast message={toastMessage} type={toastType} onClear={() => setToastMessage(null)} />}
    </div>
  );
}

export default App;
